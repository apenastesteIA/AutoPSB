/**
 * AutoPSB Web Dashboard JavaScript
 * Consome os endpoints REST do backend Node.js
 */

const API_BASE = "";
let currentSelectedLeadId = null;
let currentActiveFilter = "TODOS";

// ==========================================
// 1. INICIALIZAÇÃO & NAVEGAÇÃO DE ABAS
// ==========================================

document.addEventListener("DOMContentLoaded", () => {
  setupTabs();
  loadStats();
  loadSettings();
  loadTriggers();
  loadLeads();
  setupEventListeners();

  // Atualização periódica a cada 10 segundos
  setInterval(() => {
    loadStats();
    if (document.getElementById("tab-history").classList.contains("active")) {
      loadLeads();
      if (currentSelectedLeadId) loadLeadMessages(currentSelectedLeadId);
    }
  }, 10000);
});

function setupTabs() {
  const tabs = document.querySelectorAll(".nav-tab");
  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      document.querySelectorAll(".tab-pane").forEach(p => p.classList.remove("active"));

      tab.classList.add("active");
      const targetId = `tab-${tab.dataset.tab}`;
      const targetPane = document.getElementById(targetId);
      if (targetPane) targetPane.classList.add("active");

      if (tab.dataset.tab === "home") loadStats();
      if (tab.dataset.tab === "triggers") loadTriggers();
      if (tab.dataset.tab === "history") loadLeads();
    });
  });
}

// ==========================================
// 2. CARREGAR ESTATÍSTICAS E KPIS
// ==========================================

async function loadStats() {
  try {
    const res = await fetch(`${API_BASE}/api/stats`);
    const data = await res.json();

    document.getElementById("kpi-total-leads").innerText = data.totalLeads;
    document.getElementById("kpi-new-leads").innerText = data.newLeads;
    document.getElementById("kpi-recurring-leads").innerText = data.recurringLeads;
    document.getElementById("kpi-returned-leads").innerText = data.returnedLeads;
    document.getElementById("active-windows-count").innerText = `${data.activeWindows} ativas`;

    // Atualiza barra de proporção
    const total = data.totalLeads || 1;
    const newPct = Math.round((data.newLeads / total) * 100);
    const recurPct = Math.round((data.recurringLeads / total) * 100);
    const retPct = Math.round((data.returnedLeads / total) * 100);

    document.getElementById("bar-new").style.width = `${newPct}%`;
    document.getElementById("bar-recurring").style.width = `${recurPct}%`;
    document.getElementById("bar-returned").style.width = `${retPct}%`;
  } catch (err) {
    console.error("Erro ao carregar stats:", err);
  }
}

// ==========================================
// 3. CONFIGURAÇÃO DE MENSAGENS E GATILHOS
// ==========================================

async function loadSettings() {
  try {
    const res = await fetch(`${API_BASE}/api/settings`);
    const s = await res.json();

    document.getElementById("welcome-enabled").checked = s.welcomeEnabled;
    document.getElementById("company-name-input").value = s.businessName;
    document.getElementById("welcome-text-input").value = s.welcomeMessage;
    document.getElementById("welcome-buttons-input").value = (s.welcomeButtons || []).join(", ");

    document.getElementById("hours-enabled").checked = s.businessHoursEnabled;
    document.getElementById("start-hour-input").value = s.startHour;
    document.getElementById("end-hour-input").value = s.endHour;
    document.getElementById("off-hours-msg-input").value = s.offHoursMessage;
  } catch (err) {
    console.error("Erro ao carregar settings:", err);
  }
}

async function loadTriggers() {
  try {
    const res = await fetch(`${API_BASE}/api/triggers`);
    const triggers = await res.json();
    const container = document.getElementById("triggers-list-container");
    container.innerHTML = "";

    triggers.forEach(t => {
      const card = document.createElement("div");
      card.className = "trigger-item-card";
      card.style = "background: #f8faf9; border: 1px solid #e2e8f0; border-radius: 10px; padding: 14px; margin-top: 10px;";
      card.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <div>
            <strong style="font-size: 14px; color: #075E54;">${t.name}</strong>
            <span style="font-size: 11px; color: #64748b; margin-left: 8px;">(${t.matchCount} disparos)</span>
          </div>
          <span class="badge ${t.isActive ? 'badge-recorrente' : 'badge-novo'}">${t.isActive ? 'Ativo' : 'Pausado'}</span>
        </div>
        <p style="font-size: 12px; color: #128C7E; font-weight: 600; margin: 4px 0;">Gatilhos: ${t.keywords.join(", ")}</p>
        <p style="font-size: 12px; color: #334155;">${t.responseTemplate}</p>
        ${t.quickButtons && t.quickButtons.length ? `<p style="font-size: 11px; color: #075E54; margin-top: 4px;"><strong>Opções:</strong> ${t.quickButtons.join(" | ")}</p>` : ''}
      `;
      container.appendChild(card);
    });
  } catch (err) {
    console.error("Erro ao carregar gatilhos:", err);
  }
}

// ==========================================
// 4. HISTÓRICO DE MENSAGENS E ATENDIMENTO
// ==========================================

async function loadLeads() {
  try {
    const searchVal = document.getElementById("search-leads-input")?.value || "";
    const res = await fetch(`${API_BASE}/api/leads?filter=${currentActiveFilter}&query=${encodeURIComponent(searchVal)}`);
    const leads = await res.json();

    const container = document.getElementById("leads-list-scroll");
    container.innerHTML = "";

    // Atualiza lista na Home também
    const homeContainer = document.getElementById("active-leads-container");
    if (homeContainer) homeContainer.innerHTML = "";

    leads.forEach(lead => {
      const item = document.createElement("div");
      item.className = `lead-item ${currentSelectedLeadId === lead.id ? 'active' : ''}`;
      item.onclick = () => selectLead(lead.id);

      const badgeClass = lead.leadType === "NOVO" ? "badge-novo" : (lead.leadType === "RECORRENTE" ? "badge-recorrente" : "badge-retornou");
      const badgeText = lead.leadType === "NOVO" ? "Novo Lead" : (lead.leadType === "RECORRENTE" ? "Recorrente" : "Retornou (>7d)");

      const remainingH = Math.floor(lead.remainingWindowMinutes / 60);

      item.innerHTML = `
        <div class="avatar">${lead.name.charAt(0).toUpperCase()}</div>
        <div style="flex: 1;">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <strong style="font-size: 13px;">${lead.name}</strong>
            <span class="badge ${badgeClass}">${badgeText}</span>
          </div>
          <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 4px;">
            <span style="font-size: 11px; color: #64748b;">${lead.phoneNumber}</span>
            <span style="font-size: 10px; color: ${lead.isWindowActive ? '#16a34a' : '#ef4444'}; font-weight: 600;">
              ${lead.isWindowActive ? `⏳ ${remainingH}h rest.` : 'Janela Expirada'}
            </span>
          </div>
        </div>
      `;
      container.appendChild(item);

      // Injeta na Home se janela ativa
      if (homeContainer && lead.isWindowActive) {
        const homeItem = item.cloneNode(true);
        homeItem.onclick = () => {
          document.querySelector('[data-tab="history"]').click();
          selectLead(lead.id);
        };
        homeContainer.appendChild(homeItem);
      }
    });
  } catch (err) {
    console.error("Erro ao carregar leads:", err);
  }
}

async function selectLead(leadId) {
  currentSelectedLeadId = leadId;
  document.getElementById("chat-empty-state").classList.add("hidden");
  document.getElementById("chat-active-view").classList.remove("hidden");
  await loadLeadMessages(leadId);
  loadLeads();
}

async function loadLeadMessages(leadId) {
  try {
    const res = await fetch(`${API_BASE}/api/leads/${leadId}/messages`);
    const data = await res.json();
    const { lead, messages } = data;

    document.getElementById("chat-avatar").innerText = lead.name.charAt(0).toUpperCase();
    document.getElementById("chat-lead-name").innerText = lead.name;
    document.getElementById("chat-lead-phone").innerText = lead.phoneNumber;

    const badge = document.getElementById("chat-lead-badge");
    badge.className = `badge ${lead.leadType === "NOVO" ? 'badge-novo' : (lead.leadType === "RECORRENTE" ? 'badge-recorrente' : 'badge-retornou')}`;
    badge.innerText = lead.leadType === "NOVO" ? "Novo Lead" : (lead.leadType === "RECORRENTE" ? "Recorrente" : "Retornou (>7d)");

    const remainingH = Math.floor(lead.remainingWindowMinutes / 60);
    document.getElementById("chat-window-badge").innerText = lead.isWindowActive
      ? `⏳ Janela Meta 24h: ${remainingH}h restantes`
      : `⚠️ Janela 24h Expirada (Requer Template)`;

    const msgContainer = document.getElementById("chat-messages-scroll");
    msgContainer.innerHTML = "";

    messages.forEach(m => {
      const isClient = m.sender === "CLIENTE";
      const bubble = document.createElement("div");
      bubble.className = `message-bubble ${isClient ? 'client' : (m.sender === 'BOT' ? 'bot' : 'agent')}`;

      const dateStr = new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      bubble.innerHTML = `
        <div class="msg-sender-tag">${isClient ? 'Cliente' : (m.sender === 'BOT' ? 'AutoPSB (Bot)' : 'Atendente Humano')}</div>
        <div>${m.content}</div>
        ${m.quickButtons && m.quickButtons.length ? `<div style="margin-top: 6px; font-weight: 600; color: #075E54; font-size: 11px;">Opções: ${m.quickButtons.join(' | ')}</div>` : ''}
        <span class="msg-time">${dateStr}</span>
      `;
      msgContainer.appendChild(bubble);
    });

    msgContainer.scrollTop = msgContainer.scrollHeight;
  } catch (err) {
    console.error("Erro ao carregar mensagens:", err);
  }
}

// ==========================================
// 5. EVENT LISTENERS
// ==========================================

function setupEventListeners() {
  // Salvar Boas-Vindas
  document.getElementById("btn-save-welcome")?.addEventListener("click", async () => {
    const payload = {
      welcomeEnabled: document.getElementById("welcome-enabled").checked,
      businessName: document.getElementById("company-name-input").value,
      welcomeMessage: document.getElementById("welcome-text-input").value,
      welcomeButtons: document.getElementById("welcome-buttons-input").value.split(",").map(b => b.trim())
    };
    await fetch(`${API_BASE}/api/settings`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    alert("Mensagem de Boas-Vindas salva com sucesso!");
  });

  // Salvar Horários
  document.getElementById("btn-save-hours")?.addEventListener("click", async () => {
    const payload = {
      businessHoursEnabled: document.getElementById("hours-enabled").checked,
      startHour: document.getElementById("start-hour-input").value,
      endHour: document.getElementById("end-hour-input").value,
      offHoursMessage: document.getElementById("off-hours-msg-input").value
    };
    await fetch(`${API_BASE}/api/settings`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    alert("Horários comerciais salvos com sucesso!");
  });

  // Enviar Resposta Humana no Chat
  document.getElementById("btn-send-agent-reply")?.addEventListener("click", async () => {
    const input = document.getElementById("agent-reply-input");
    const content = input.value.trim();
    if (!content || !currentSelectedLeadId) return;

    await fetch(`${API_BASE}/api/leads/${currentSelectedLeadId}/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content })
    });
    input.value = "";
    loadLeadMessages(currentSelectedLeadId);
  });

  // Filtros de Leads
  document.querySelectorAll(".filter-pill").forEach(pill => {
    pill.addEventListener("click", () => {
      document.querySelectorAll(".filter-pill").forEach(p => p.classList.remove("active"));
      pill.classList.add("active");
      currentActiveFilter = pill.dataset.filter;
      loadLeads();
    });
  });

  // Busca de Leads
  document.getElementById("search-leads-input")?.addEventListener("input", () => {
    loadLeads();
  });

  // Simulador
  document.getElementById("btn-run-simulation")?.addEventListener("click", async () => {
    const phone = document.getElementById("sim-phone").value;
    const name = document.getElementById("sim-name").value;
    const msg = document.getElementById("sim-msg").value;

    const logCard = document.getElementById("sim-log-card");
    const feedbackBox = document.getElementById("sim-feedback-box");
    logCard.classList.remove("hidden");
    feedbackBox.innerHTML = "⏳ Enviando webhook simulado para a Meta Cloud API...";

    const res = await fetch(`${API_BASE}/api/simulate-incoming`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phoneNumber: phone, name, message: msg })
    });
    const result = await res.json();

    feedbackBox.innerHTML = `
      <div style="color: #16a34a; font-weight: 700;">✅ Mensagem recebida e processada com sucesso pelo AutoPSB!</div>
      <p style="margin-top: 6px; font-size: 13px;">O bot respondeu com delay humanizado e a Janela de 24h foi renovada.</p>
      <button class="btn btn-secondary mt-3" onclick="viewSimulatedLead('${result.leadId}')">Ver Conversa no Histórico</button>
    `;
    loadStats();
  });
}

function loadPreset(phone, name, msg) {
  document.getElementById("sim-phone").value = phone;
  document.getElementById("sim-name").value = name;
  document.getElementById("sim-msg").value = msg;
}

function viewSimulatedLead(leadId) {
  document.querySelector('[data-tab="history"]').click();
  selectLead(leadId);
}
