/**
 * AutoPSB Database Module
 * Armazena em memória (com inicialização de dados demonstrativos) os leads,
 * histórico de conversas, regras de gatilhos e configurações do comércio.
 */

const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;
const TWENTY_FOUR_HOURS_MS = 24 * 60 * 60 * 1000;

class AutoPsbDatabase {
  constructor() {
    this.settings = {
      businessName: "Empório & Sabores Gourmet",
      welcomeEnabled: true,
      welcomeMessage: "{saudacao}! Seja bem-vindo(a) ao {empresa}! 😊 Como podemos te ajudar hoje? Escolha uma opção ou digite sua dúvida:",
      welcomeButtons: ["Cardápio e Preços", "Endereço e Horários", "Chave PIX", "Atendente Humano"],
      businessHoursEnabled: true,
      startHour: "08:00",
      endHour: "20:00",
      workDays: "Segunda a Sábado",
      offHoursMessage: "Olá! No momento estamos fora do nosso expediente comercial (Seg a Sex das 08h às 20h). Deixe sua mensagem que responderemos logo cedo!",
      humanizedDelayEnabled: true,
      minDelaySeconds: 2,
      maxDelaySeconds: 4,
      metaPhoneNumberId: process.env.META_PHONE_NUMBER_ID || "104829104812345",
      metaAccessToken: process.env.META_ACCESS_TOKEN || "EAAG...MetaCloudApiToken",
      metaWebhookVerifyToken: process.env.WEBHOOK_VERIFY_TOKEN || "autopsb_verify_token_2025"
    };

    this.triggers = [
      {
        id: "trg_1",
        name: "Preço & Cardápio",
        keywords: ["preco", "preço", "valor", "cardapio", "cardápio", "quanto custa", "tabela"],
        actionType: "BOTOES",
        responseTemplate: "Nosso cardápio atualizado e promoções da semana estão disponíveis! Temos opções a partir de R$ 24,90. O que gostaria de conferir?",
        quickButtons: ["Pratos Executivos", "Sobremesas", "Fazer Pedido"],
        delaySeconds: 2,
        includeGreeting: false,
        isActive: true,
        matchCount: 18
      },
      {
        id: "trg_2",
        name: "Endereço & Localização",
        keywords: ["endereco", "endereço", "onde fica", "localizacao", "localização", "maps", "rua"],
        actionType: "TEXTO",
        responseTemplate: "📍 Estamos localizados na Av. das Flores, nº 340 - Centro (próximo à Praça Central). Temos convênio com estacionamento em frente!",
        quickButtons: ["Como Chegar", "Ver Fotos"],
        delaySeconds: 2,
        includeGreeting: false,
        isActive: true,
        matchCount: 12
      },
      {
        id: "trg_3",
        name: "Formas de Pagamento & PIX",
        keywords: ["pix", "chave pix", "pagar", "pagamento", "cartao", "cartão"],
        actionType: "TEXTO",
        responseTemplate: "Aceitamos PIX, cartões de crédito e débito! 💳 Nossa chave PIX CNPJ é: 12.345.678/0001-90 (Empório e Sabores Ltda). Favor enviar comprovante por aqui.",
        quickButtons: ["Copiar Chave PIX", "Enviar Comprovante"],
        delaySeconds: 2,
        includeGreeting: false,
        isActive: true,
        matchCount: 9
      },
      {
        id: "trg_4",
        name: "Atendimento Humano",
        keywords: ["humano", "atendente", "falar com pessoa", "suporte", "atendente humano"],
        actionType: "HUMANO",
        responseTemplate: "Entendido! Estou direcionando você agora para um de nossos atendentes humanos. Um instante que já vamos te responder!",
        quickButtons: ["Cancelar Espera"],
        delaySeconds: 1,
        includeGreeting: false,
        isActive: true,
        matchCount: 7
      }
    ];

    const now = Date.now();

    this.leads = [
      {
        id: "lead_1",
        phoneNumber: "5511987654321",
        name: "Mariana Alves",
        leadType: "NOVO", // Primeiro contato
        firstContact: now - (2 * 60 * 60 * 1000),
        lastInteraction: now - (2 * 60 * 60 * 1000),
        lastCustomerMessageTime: now - (2 * 60 * 60 * 1000),
        messageCount: 2,
        status: "RESPONDIDO",
        tags: ["Novo Lead", "Interessada em Cardápio"]
      },
      {
        id: "lead_2",
        phoneNumber: "5511971238899",
        name: "Rodrigo Mendes",
        leadType: "RECORRENTE", // Habitual
        firstContact: now - (30 * 24 * 60 * 60 * 1000),
        lastInteraction: now - (5 * 60 * 60 * 1000),
        lastCustomerMessageTime: now - (5 * 60 * 60 * 1000),
        messageCount: 19,
        status: "CONVERTIDO",
        tags: ["Cliente Fiel", "Pedido Semanal"]
      },
      {
        id: "lead_3",
        phoneNumber: "5511965432100",
        name: "Juliana Costa",
        leadType: "RETORNOU", // Inativo > 7 dias e voltou!
        firstContact: now - (50 * 24 * 60 * 60 * 1000),
        lastInteraction: now - (35 * 60 * 1000),
        lastCustomerMessageTime: now - (35 * 60 * 1000),
        messageCount: 8,
        status: "AGUARDANDO_HUMANO",
        tags: ["Retornou (>7 dias)", "Orçamento Evento"]
      }
    ];

    this.messages = [
      {
        id: "msg_1",
        leadId: "lead_1",
        sender: "CLIENTE",
        content: "Olá, boa tarde! Gostaria de saber o cardápio e os preços de hoje.",
        timestamp: now - (2 * 60 * 60 * 1000),
        type: "TEXTO"
      },
      {
        id: "msg_2",
        leadId: "lead_1",
        sender: "BOT",
        content: "Boa tarde Mariana Alves! Nosso cardápio atualizado e promoções da semana estão disponíveis! Temos opções a partir de R$ 24,90. O que gostaria de conferir?",
        timestamp: now - (2 * 60 * 60 * 1000) + 3000,
        type: "BOTOES",
        quickButtons: ["Pratos Executivos", "Sobremesas", "Fazer Pedido"],
        triggerMatched: "Preço & Cardápio"
      },
      {
        id: "msg_3",
        leadId: "lead_2",
        sender: "CLIENTE",
        content: "Oi! Qual a chave PIX de vocês mesmo? Vou adiantar o pagamento do pedido.",
        timestamp: now - (5 * 60 * 60 * 1000),
        type: "TEXTO"
      },
      {
        id: "msg_4",
        leadId: "lead_2",
        sender: "BOT",
        content: "Olá Rodrigo Mendes! Aceitamos PIX, cartões de crédito e débito! 💳 Nossa chave PIX CNPJ é: 12.345.678/0001-90. Favor enviar comprovante por aqui.",
        timestamp: now - (5 * 60 * 60 * 1000) + 2000,
        type: "TEXTO",
        triggerMatched: "Formas de Pagamento & PIX"
      },
      {
        id: "msg_5",
        leadId: "lead_3",
        sender: "CLIENTE",
        content: "Olá sumidos! Queria falar com um atendente humano para um orçamento de evento.",
        timestamp: now - (35 * 60 * 1000),
        type: "TEXTO"
      },
      {
        id: "msg_6",
        leadId: "lead_3",
        sender: "BOT",
        content: "Entendido Juliana Costa! Que bom ter você de volta conosco! 😊 Estou direcionando você agora para um de nossos atendentes humanos. Um instante!",
        timestamp: now - (35 * 60 * 1000) + 2000,
        type: "BOTOES",
        quickButtons: ["Cancelar Espera"],
        triggerMatched: "Atendimento Humano"
      }
    ];
  }

  // Helper para verificar Janela de 24h da Meta
  isWindowActive(lead) {
    if (!lead || !lead.lastCustomerMessageTime) return false;
    const elapsed = Date.now() - lead.lastCustomerMessageTime;
    return elapsed < TWENTY_FOUR_HOURS_MS;
  }

  getRemainingWindowMinutes(lead) {
    if (!lead || !lead.lastCustomerMessageTime) return 0;
    const elapsed = Date.now() - lead.lastCustomerMessageTime;
    const remaining = TWENTY_FOUR_HOURS_MS - elapsed;
    return remaining > 0 ? Math.floor(remaining / (60 * 1000)) : 0;
  }

  findLeadByPhone(phone) {
    const cleanPhone = phone.replace(/\D/g, "");
    return this.leads.find(l => l.phoneNumber.replace(/\D/g, "") === cleanPhone);
  }

  findLeadById(id) {
    return this.leads.find(l => l.id === id);
  }

  getMessagesForLead(leadId) {
    return this.messages.filter(m => m.leadId === leadId).sort((a, b) => a.timestamp - b.timestamp);
  }

  classifyLeadType(existingLead) {
    if (!existingLead) return "NOVO";
    const elapsed = Date.now() - existingLead.lastInteraction;
    if (elapsed > SEVEN_DAYS_MS) {
      return "RETORNOU"; // Ficou mais de 7 dias sem falar e voltou!
    }
    return "RECORRENTE";
  }

  addMessage(msg) {
    const newMsg = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      timestamp: Date.now(),
      ...msg
    };
    this.messages.push(newMsg);
    return newMsg;
  }
}

module.exports = new AutoPsbDatabase();
