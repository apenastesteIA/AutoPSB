# AutoPSB (APSB) v1.0 - Backend Node.js & Painel Web

Software SaaS voltado para pequenos comércios que precisam automatizar o atendimento no WhatsApp sem perder a humanização.

## 🚀 Funcionalidades Principais

1. **Conexão Oficial WhatsApp Business Cloud API da Meta (Graph API v21.0)**:
   - Webhook oficial para recebimento de mensagens (`GET /webhook` para verificação de token e `POST /webhook` para recebimento de eventos).
   - Envio de mensagens livres, botões de escolha rápida (`interactive.button`), listas e templates.
2. **Respeito às Regras da Janela de 24 Horas da Meta**:
   - Cada mensagem do cliente abre ou reinicia uma janela de atendimento de 24 horas.
   - O painel exibe um cronômetro visual com o tempo restante e alertas caso a janela tenha expirado.
3. **Métricas de Captação e Retenção de Leads**:
   - **Novos Leads**: Clientes que enviaram o primeiro contato.
   - **Clientes Recorrentes**: Clientes que conversam frequentemente com a loja.
   - **Clientes que Retornaram**: Clientes que ficaram inativos por mais de 7 dias e voltaram a entrar em contato (medindo a retenção da empresa!).
4. **Respostas Humanizadas com Delay Natural**:
   - Simulação de digitação ("digitando...") com delay configurável de 2 a 4 segundos para evitar frieza robótica.
   - Saudações dinâmicas de acordo com o horário do dia ("Bom dia", "Boa tarde", "Boa noite").
   - Interpolação de variáveis: `{saudacao}`, `{empresa}`, `{nome}`.
5. **Horário Comercial & Fora de Expediente**:
   - Detecção automática de horário de atendimento com mensagem específica fora do expediente.
6. **Histórico de Conversas Pesquisável**:
   - Filtros rápidos por Novos, Recorrentes, Retornaram e Aguardando Atendente Humano.
   - Possibilidade de intervenção manual em tempo real por um atendente da loja.
7. **Simulador WhatsApp Integrado**:
   - Permite ao comerciante testar cenários e verificar na hora a resposta do bot.

---

## 🛠️ Como Executar o Backend Node.js

### Requisitos:
- Node.js 18+ instalado

### Passos:
```bash
cd backend-nodejs
npm install
npm start
```

O servidor iniciará em `http://localhost:3000`:
- **Painel Web**: `http://localhost:3000`
- **Webhook da Meta**: `http://localhost:3000/webhook`
- **API REST**: `http://localhost:3000/api/...`

---

## 📱 Aplicativo Mobile Android (AutoPSB)

O projeto também conta com o aplicativo nativo para Android em **Jetpack Compose + Material 3 + Room Database**, permitindo que o comerciante acompanhe e gerencie tudo diretamente pelo celular.
