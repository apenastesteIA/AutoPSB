/**
 * AutoPSB v1.0 - Servidor Express Node.js
 * Atendimento Humanizado e Automação para WhatsApp Business Cloud API
 */

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");

const db = require("./database/memoryDb");
const { processIncomingMessage } = require("./services/automationEngine");
const MetaCloudService = require("./services/metaCloudService");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Instância do serviço da Meta Cloud API
function getMetaClient() {
  return new MetaCloudService(db.settings.metaPhoneNumberId, db.settings.metaAccessToken);
}

// ==========================================
// 1. ENDPOINTS OFICIAIS DO WEBHOOK DA META
// ==========================================

/**
 * Validação do Webhook pelo painel do Meta for Developers (GET /webhook)
 */
app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token === db.settings.metaWebhookVerifyToken) {
    console.log("✅ Webhook verificado com sucesso pela Meta!");
    return res.status(200).send(challenge);
  }
  console.warn("❌ Falha na verificação do Webhook. Token incorreto.");
  return res.sendStatus(403);
});

/**
 * Recebimento de Mensagens do WhatsApp em Tempo Real (POST /webhook)
 */
app.post("/webhook", async (req, res) => {
  res.status(200).send("EVENT_RECEIVED");

  try {
    const entry = req.body.entry?.[0];
    const change = entry?.changes?.[0]?.value;
    const message = change?.messages?.[0];

    if (!message) return; // Notificação de status (entregue/lido) ignorada

    const fromPhone = message.from;
    const contactProfile = change?.contacts?.[0]?.profile;
    const senderName = contactProfile?.name || "Cliente WhatsApp";

    // Extrai o conteúdo da mensagem (texto livre ou clique em botão de resposta rápida)
    let messageText = "";
    if (message.type === "text") {
      messageText = message.text?.body || "";
    } else if (message.type === "interactive") {
      messageText = message.interactive?.button_reply?.title || message.interactive?.list_reply?.title || "";
    }

    if (!messageText) return;

    await handleIncomingWhatsAppMessage(fromPhone, senderName, messageText);
  } catch (err) {
    console.error("Erro ao processar webhook da Meta:", err);
  }
});

// ==========================================
// 2. FUNÇÃO CENTRAL DE PROCESSAMENTO DO BOT
// ==========================================

async function handleIncomingWhatsAppMessage(fromPhone, senderName, messageText) {
  const now = Date.now();
  let lead = db.findLeadByPhone(fromPhone);

  // 1. Classificação de Lead (Novo, Recorrente ou Retornou)
  const leadType = db.classifyLeadType(lead);

  if (!lead) {
    lead = {
      id: `lead_${Date.now()}`,
      phoneNumber: fromPhone,
      name: senderName,
      leadType: "NOVO",
      firstContact: now,
      lastInteraction: now,
      lastCustomerMessageTime: now, // Inicia a janela de 24h
      messageCount: 1,
      status: "EM_ATENDIMENTO",
      tags: ["Novo Lead"]
    };
    db.leads.unshift(lead);
  } else {
    lead.leadType = leadType;
    lead.lastInteraction = now;
    lead.lastCustomerMessageTime = now; // Reinicia a janela de 24h
    lead.messageCount += 1;
    lead.status = "EM_ATENDIMENTO";
  }

  // 2. Registra mensagem do cliente
  db.addMessage({
    leadId: lead.id,
    sender: "CLIENTE",
    content: messageText,
    type: "TEXTO"
  });

  // 3. Processa automação e gatilhos
  const response = processIncomingMessage(messageText, senderName, leadType, db.triggers, db.settings);

  // 4. Delay humanizado
  if (response.delayMs > 0 && db.settings.humanizedDelayEnabled) {
    await new Promise(resolve => setTimeout(resolve, response.delayMs));
  }

  // 5. Envia resposta via Meta Cloud API
  const metaClient = getMetaClient();
  if (response.quickButtons && response.quickButtons.length > 0) {
    await metaClient.sendInteractiveButtons(fromPhone, response.replyText, response.quickButtons);
  } else {
    await metaClient.sendTextMessage(fromPhone, response.replyText);
  }

  // 6. Registra mensagem enviada pelo bot
  db.addMessage({
    leadId: lead.id,
    sender: "BOT",
    content: response.replyText,
    type: response.actionType === "BOTOES" ? "BOTOES" : "TEXTO",
    quickButtons: response.quickButtons,
    triggerMatched: response.triggerMatched
  });

  lead.status = response.requiresHuman ? "AGUARDANDO_HUMANO" : "RESPONDIDO";
  lead.lastInteraction = Date.now();
  return lead;
}

// ==========================================
// 3. ENDPOINTS REST PARA O PAINEL WEB
// ==========================================

// Estatísticas e Métricas de Retenção
app.get("/api/stats", (req, res) => {
  const total = db.leads.length;
  const newLeads = db.leads.filter(l => l.leadType === "NOVO").length;
  const recurring = db.leads.filter(l => l.leadType === "RECORRENTE").length;
  const returned = db.leads.filter(l => l.leadType === "RETORNOU").length;
  const activeWindows = db.leads.filter(l => db.isWindowActive(l)).length;

  res.json({
    totalLeads: total,
    newLeads,
    recurringLeads: recurring,
    returnedLeads: returned,
    activeWindows,
    responseRate: "100%",
    avgResponseTime: "2.4s"
  });
});

// Listagem de Leads
app.get("/api/leads", (req, res) => {
  const { filter, query } = req.query;
  let result = db.leads.map(l => ({
    ...l,
    isWindowActive: db.isWindowActive(l),
    remainingWindowMinutes: db.getRemainingWindowMinutes(l)
  }));

  if (filter && filter !== "TODOS") {
    if (filter === "AGUARDANDO_HUMANO") {
      result = result.filter(l => l.status === "AGUARDANDO_HUMANO");
    } else {
      result = result.filter(l => l.leadType === filter);
    }
  }

  if (query) {
    const q = query.toLowerCase();
    result = result.filter(l => l.name.toLowerCase().includes(q) || l.phoneNumber.includes(q));
  }

  res.json(result);
});

// Mensagens de um Lead
app.get("/api/leads/:id/messages", (req, res) => {
  const lead = db.findLeadById(req.params.id);
  if (!lead) return res.status(404).json({ error: "Lead não encontrado" });

  const messages = db.getMessagesForLead(req.params.id);
  res.json({
    lead: {
      ...lead,
      isWindowActive: db.isWindowActive(lead),
      remainingWindowMinutes: db.getRemainingWindowMinutes(lead)
    },
    messages
  });
});

// Envio de Resposta Manual pelo Atendente Humano
app.post("/api/leads/:id/messages", async (req, res) => {
  const lead = db.findLeadById(req.params.id);
  if (!lead) return res.status(404).json({ error: "Lead não encontrado" });

  const { content } = req.body;
  if (!content) return res.status(400).json({ error: "Mensagem vazia" });

  // Envio via Meta API
  const metaClient = getMetaClient();
  await metaClient.sendTextMessage(lead.phoneNumber, content);

  const newMsg = db.addMessage({
    leadId: lead.id,
    sender: "ATENDENTE",
    content,
    type: "TEXTO"
  });

  lead.status = "RESPONDIDO";
  lead.lastInteraction = Date.now();
  lead.messageCount += 1;

  res.json(newMsg);
});

// Gatilhos e Palavras-chave
app.get("/api/triggers", (req, res) => {
  res.json(db.triggers);
});

app.post("/api/triggers", (req, res) => {
  const { name, keywords, actionType, responseTemplate, quickButtons, delaySeconds } = req.body;
  const newTrigger = {
    id: `trg_${Date.now()}`,
    name,
    keywords: Array.isArray(keywords) ? keywords : keywords.split(",").map(k => k.trim()),
    actionType: actionType || "TEXTO",
    responseTemplate,
    quickButtons: Array.isArray(quickButtons) ? quickButtons : (quickButtons ? quickButtons.split(",").map(b => b.trim()) : []),
    delaySeconds: Number(delaySeconds) || 2,
    includeGreeting: false,
    isActive: true,
    matchCount: 0
  };
  db.triggers.push(newTrigger);
  res.status(201).json(newTrigger);
});

app.put("/api/triggers/:id", (req, res) => {
  const index = db.triggers.findIndex(t => t.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: "Gatilho não encontrado" });

  db.triggers[index] = { ...db.triggers[index], ...req.body };
  res.json(db.triggers[index]);
});

app.delete("/api/triggers/:id", (req, res) => {
  db.triggers = db.triggers.filter(t => t.id !== req.params.id);
  res.json({ success: true });
});

// Configurações do Negócio
app.get("/api/settings", (req, res) => {
  res.json(db.settings);
});

app.put("/api/settings", (req, res) => {
  db.settings = { ...db.settings, ...req.body };
  res.json(db.settings);
});

// Simulador: Permite testar o recebimento de mensagens no backend
app.post("/api/simulate-incoming", async (req, res) => {
  const { phoneNumber, name, message } = req.body;
  if (!phoneNumber || !message) {
    return res.status(400).json({ error: "Número e mensagem são obrigatórios" });
  }

  const lead = await handleIncomingWhatsAppMessage(phoneNumber, name || "Cliente Teste", message);
  res.json({ success: true, leadId: lead.id });
});

// Iniciar Servidor
app.listen(PORT, () => {
  console.log(`=========================================`);
  console.log(`🤖 AutoPSB v1.0 Backend Ativo na porta ${PORT}`);
  console.log(`👉 Painel Web: http://localhost:${PORT}`);
  console.log(`👉 Webhook URL: http://localhost:${PORT}/webhook`);
  console.log(`=========================================`);
});
