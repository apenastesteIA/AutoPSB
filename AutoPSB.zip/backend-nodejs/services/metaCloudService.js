/**
 * AutoPSB - Meta WhatsApp Business Cloud API Client
 * Comunicação oficial com a Graph API v21.0 da Meta
 */

const axios = require("axios");

class MetaCloudService {
  constructor(phoneNumberId, accessToken) {
    this.phoneNumberId = phoneNumberId;
    this.accessToken = accessToken;
    this.apiUrl = `https://graph.facebook.com/v21.0/${phoneNumberId}/messages`;
  }

  getHeaders() {
    return {
      "Authorization": `Bearer ${this.accessToken}`,
      "Content-Type": "application/json"
    };
  }

  /**
   * Envia mensagem de texto livre dentro da janela de 24 horas da Meta
   */
  async sendTextMessage(toPhone, text) {
    if (!this.phoneNumberId || !this.accessToken || this.accessToken.startsWith("EAAG...")) {
      console.log(`[Meta API Mock/Simulador] Envio de texto para ${toPhone}: ${text}`);
      return { success: true, simulated: true };
    }

    try {
      const response = await axios.post(
        this.apiUrl,
        {
          messaging_product: "whatsapp",
          recipient_type: "individual",
          to: toPhone,
          type: "text",
          text: { preview_url: false, body: text }
        },
        { headers: this.getHeaders() }
      );
      return { success: true, data: response.data };
    } catch (err) {
      console.error("[Meta API Error]", err.response ? err.response.data : err.message);
      return { success: false, error: err.response?.data || err.message };
    }
  }

  /**
   * Envia mensagem interativa com botões de resposta rápida
   */
  async sendInteractiveButtons(toPhone, bodyText, buttonLabels) {
    if (!this.phoneNumberId || !this.accessToken || this.accessToken.startsWith("EAAG...")) {
      console.log(`[Meta API Mock/Simulador] Envio de botões para ${toPhone}: [${buttonLabels.join(", ")}]`);
      return { success: true, simulated: true };
    }

    const buttons = buttonLabels.slice(0, 3).map((lbl, idx) => ({
      type: "reply",
      reply: {
        id: `btn_${idx}_${Date.now()}`,
        title: lbl.substring(0, 20) // Limite da Meta de 20 caracteres por botão
      }
    }));

    try {
      const response = await axios.post(
        this.apiUrl,
        {
          messaging_product: "whatsapp",
          recipient_type: "individual",
          to: toPhone,
          type: "interactive",
          interactive: {
            type: "button",
            body: { text: bodyText },
            action: { buttons }
          }
        },
        { headers: this.getHeaders() }
      );
      return { success: true, data: response.data };
    } catch (err) {
      console.error("[Meta API Interactive Error]", err.response ? err.response.data : err.message);
      return { success: false, error: err.response?.data || err.message };
    }
  }

  /**
   * Envia mensagem baseada em Modelo (Template) Aprovado pela Meta
   * (Obrigatório para iniciar conversas fora da janela de 24 horas)
   */
  async sendTemplateMessage(toPhone, templateName, languageCode = "pt_BR", components = []) {
    if (!this.phoneNumberId || !this.accessToken || this.accessToken.startsWith("EAAG...")) {
      console.log(`[Meta API Mock/Simulador] Envio de Template "${templateName}" para ${toPhone}`);
      return { success: true, simulated: true };
    }

    try {
      const response = await axios.post(
        this.apiUrl,
        {
          messaging_product: "whatsapp",
          to: toPhone,
          type: "template",
          template: {
            name: templateName,
            language: { code: languageCode },
            components
          }
        },
        { headers: this.getHeaders() }
      );
      return { success: true, data: response.data };
    } catch (err) {
      console.error("[Meta API Template Error]", err.response ? err.response.data : err.message);
      return { success: false, error: err.response?.data || err.message };
    }
  }
}

module.exports = MetaCloudService;
