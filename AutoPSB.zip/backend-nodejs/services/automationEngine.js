/**
 * AutoPSB Automation Engine (Node.js)
 * Motor de processamento humanizado para WhatsApp Business Cloud API
 */

function normalizeText(text) {
  if (!text) return "";
  return text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

function getGreeting() {
  const hour = new Date().getHours();
  if (hour >= 5 && hour < 12) return "Bom dia";
  if (hour >= 12 && hour < 18) return "Boa tarde";
  return "Boa noite";
}

function isWithinBusinessHours(settings) {
  if (!settings.businessHoursEnabled) return true;
  try {
    const now = new Date();
    const currentMinutes = now.getHours() * 60 + now.getMinutes();

    const [startH, startM] = settings.startHour.split(":").map(Number);
    const [endH, endM] = settings.endHour.split(":").map(Number);

    const startMinutes = startH * 60 + startM;
    const endMinutes = endH * 60 + endM;

    return currentMinutes >= startMinutes && currentMinutes <= endMinutes;
  } catch (err) {
    return true;
  }
}

function processIncomingMessage(messageText, leadName, leadType, triggers, settings) {
  const normalized = normalizeText(messageText);
  const greeting = getGreeting();
  const company = settings.businessName;

  // 1. Verificação de Horário Comercial
  if (!isWithinBusinessHours(settings)) {
    const offHoursMsg = settings.offHoursMessage
      .replace(/{saudacao}/g, greeting)
      .replace(/{nome}/g, leadName)
      .replace(/{empresa}/g, company);

    return {
      replyText: offHoursMsg,
      quickButtons: ["Deixar Recado", "Ver Informações"],
      actionType: "TEXTO",
      triggerMatched: "Fora de Horário",
      requiresHuman: false,
      delayMs: (settings.minDelaySeconds || 2) * 1000
    };
  }

  // 2. Busca por Gatilho de Palavras-Chave
  const activeTriggers = triggers.filter(t => t.isActive);
  for (const trigger of activeTriggers) {
    const matched = trigger.keywords.some(kw => {
      const normKw = normalizeText(kw);
      return normKw && (normalized.includes(normKw) || normKw.includes(normalized));
    });

    if (matched) {
      let response = trigger.responseTemplate
        .replace(/{empresa}/g, company)
        .replace(/{nome}/g, leadName);

      if (trigger.includeGreeting) {
        response = `${greeting} ${leadName}! ${response}`;
      }

      return {
        replyText: response,
        quickButtons: trigger.quickButtons || [],
        actionType: trigger.actionType,
        triggerMatched: trigger.name,
        requiresHuman: trigger.actionType === "HUMANO",
        delayMs: (trigger.delaySeconds || 2) * 1000
      };
    }
  }

  // 3. Boas-Vindas Padrão (se não casar em nenhuma palavra-chave)
  if (settings.welcomeEnabled) {
    let welcome = settings.welcomeMessage
      .replace(/{saudacao}/g, greeting)
      .replace(/{nome}/g, leadName)
      .replace(/{empresa}/g, company);

    if (leadType === "RETORNOU") {
      welcome = `${greeting} ${leadName}! Que ótimo ter você de volta conosco! 😊\n\n${welcome}`;
    }

    return {
      replyText: welcome,
      quickButtons: settings.welcomeButtons || [],
      actionType: "BOTOES",
      triggerMatched: "Boas-Vindas Padrão",
      requiresHuman: false,
      delayMs: (settings.minDelaySeconds || 2) * 1000
    };
  }

  // 4. Fallback
  return {
    replyText: `Olá ${leadName}! Recebemos sua mensagem com sucesso. Um atendente já vai te responder!`,
    quickButtons: ["Falar com Atendente"],
    actionType: "TEXTO",
    triggerMatched: "Resposta Geral",
    requiresHuman: true,
    delayMs: 1500
  };
}

module.exports = {
  normalizeText,
  getGreeting,
  isWithinBusinessHours,
  processIncomingMessage
};
