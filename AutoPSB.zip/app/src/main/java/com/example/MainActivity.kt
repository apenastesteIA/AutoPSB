package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SettingsSuggest
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Whatsapp
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.SettingsSuggest
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MetaApiScreen
import com.example.ui.screens.SimulatorScreen
import com.example.ui.screens.TriggerConfigScreen
import com.example.ui.theme.AutoPsbTheme
import com.example.ui.theme.WpDarkTeal
import com.example.ui.theme.WpGreen
import com.example.ui.theme.WpLightGreen
import com.example.ui.theme.WpTeal
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.AutoPsbViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AutoPsbTheme {
                AutoPsbApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutoPsbApp(
    viewModel: AutoPsbViewModel = viewModel()
) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val selectedLeadId by viewModel.selectedLeadId.collectAsStateWithLifecycle()

    // Trata botão voltar do Android: se estiver vendo chat de lead, desfaz seleção; se em outra aba, volta pra Home
    BackHandler(enabled = currentTab != AppNavTab.HOME || selectedLeadId != null) {
        if (selectedLeadId != null) {
            viewModel.selectLead(null)
        } else {
            viewModel.selectTab(AppNavTab.HOME)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(WpGreen),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = "Logo AutoPSB",
                                tint = WpDarkTeal,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "AutoPSB",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color.White.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "WhatsApp SaaS v1.0",
                                fontSize = 10.sp,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                },
                actions = {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(WpGreen)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Meta Cloud API",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = WpDarkTeal,
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("main_navigation_bar")
            ) {
                NavigationBarItem(
                    selected = currentTab == AppNavTab.HOME,
                    onClick = {
                        viewModel.selectLead(null)
                        viewModel.selectTab(AppNavTab.HOME)
                    },
                    icon = {
                        Icon(
                            if (currentTab == AppNavTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                            contentDescription = "Home"
                        )
                    },
                    label = { Text("Home", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = WpDarkTeal,
                        selectedTextColor = WpDarkTeal,
                        indicatorColor = WpLightGreen
                    )
                )

                NavigationBarItem(
                    selected = currentTab == AppNavTab.TRIGGERS,
                    onClick = {
                        viewModel.selectLead(null)
                        viewModel.selectTab(AppNavTab.TRIGGERS)
                    },
                    icon = {
                        Icon(
                            if (currentTab == AppNavTab.TRIGGERS) Icons.Filled.Tune else Icons.Outlined.Tune,
                            contentDescription = "Configuração de Mensagens"
                        )
                    },
                    label = { Text("Gatilhos", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = WpDarkTeal,
                        selectedTextColor = WpDarkTeal,
                        indicatorColor = WpLightGreen
                    )
                )

                NavigationBarItem(
                    selected = currentTab == AppNavTab.HISTORY,
                    onClick = {
                        viewModel.selectTab(AppNavTab.HISTORY)
                    },
                    icon = {
                        Icon(
                            if (currentTab == AppNavTab.HISTORY) Icons.Filled.History else Icons.Outlined.History,
                            contentDescription = "Histórico de Atendimento"
                        )
                    },
                    label = { Text("Histórico", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = WpDarkTeal,
                        selectedTextColor = WpDarkTeal,
                        indicatorColor = WpLightGreen
                    )
                )

                NavigationBarItem(
                    selected = currentTab == AppNavTab.SIMULATOR,
                    onClick = {
                        viewModel.selectLead(null)
                        viewModel.selectTab(AppNavTab.SIMULATOR)
                    },
                    icon = {
                        Icon(
                            if (currentTab == AppNavTab.SIMULATOR) Icons.Filled.PlayArrow else Icons.Outlined.PlayArrow,
                            contentDescription = "Simulador"
                        )
                    },
                    label = { Text("Simulador", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = WpDarkTeal,
                        selectedTextColor = WpDarkTeal,
                        indicatorColor = WpLightGreen
                    )
                )

                NavigationBarItem(
                    selected = currentTab == AppNavTab.META_API,
                    onClick = {
                        viewModel.selectLead(null)
                        viewModel.selectTab(AppNavTab.META_API)
                    },
                    icon = {
                        Icon(
                            if (currentTab == AppNavTab.META_API) Icons.Filled.SettingsSuggest else Icons.Outlined.SettingsSuggest,
                            contentDescription = "Meta Cloud API"
                        )
                    },
                    label = { Text("Meta API", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = WpDarkTeal,
                        selectedTextColor = WpDarkTeal,
                        indicatorColor = WpLightGreen
                    )
                )
            }
        }
    ) { innerPadding ->
        Crossfade(
            targetState = currentTab,
            label = "tab_transition",
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) { tab ->
            when (tab) {
                AppNavTab.HOME -> HomeScreen(viewModel = viewModel)
                AppNavTab.TRIGGERS -> TriggerConfigScreen(viewModel = viewModel)
                AppNavTab.HISTORY -> HistoryScreen(viewModel = viewModel)
                AppNavTab.SIMULATOR -> SimulatorScreen(viewModel = viewModel)
                AppNavTab.META_API -> MetaApiScreen(viewModel = viewModel)
            }
        }
    }
}
