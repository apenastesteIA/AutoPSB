package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.BusinessSettingsEntity
import com.example.data.model.TriggerActionType
import com.example.data.model.TriggerRuleEntity
import com.example.ui.theme.WpDarkTeal
import com.example.ui.theme.WpGreen
import com.example.ui.theme.WpTeal
import com.example.ui.viewmodel.AutoPsbViewModel

@Composable
fun TriggerConfigScreen(
    viewModel: AutoPsbViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val triggerRules by viewModel.triggerRules.collectAsStateWithLifecycle()

    var showEditWelcomeDialog by remember { mutableStateOf(false) }
    var showEditHoursDialog by remember { mutableStateOf(false) }
    var editingRule by remember { mutableStateOf<TriggerRuleEntity?>(null) }
    var isCreatingNewRule by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingRule = TriggerRuleEntity(
                        name = "",
                        keywords = "",
                        actionType = TriggerActionType.TEXTO_SIMPLES.name,
                        responseTemplate = "",
                        quickButtons = "",
                        delaySeconds = 2,
                        includeGreeting = true
                    )
                    isCreatingNewRule = true
                },
                containerColor = WpTeal,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_trigger_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Adicionar Gatilho")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("trigger_config_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Título & Explicação
            item {
                Column {
                    Text(
                        text = "Configuração de Mensagens",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Configure respostas humanizadas e gatilhos por palavras-chave sem precisar programar.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // 1. Card Boas-Vindas Humanizadas
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("welcome_config_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(WpTeal.copy(alpha = 0.12f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, tint = WpTeal)
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Boas-Vindas Humanizada",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        text = "Primeira mensagem para novos contatos",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(
                                checked = settings.welcomeEnabled,
                                onCheckedChange = { viewModel.updateSettings(settings.copy(welcomeEnabled = it)) },
                                colors = SwitchDefaults.colors(checkedThumbColor = WpTeal, checkedTrackColor = WpGreen.copy(alpha = 0.5f))
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = settings.welcomeMessage,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                if (settings.welcomeButtons.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Botões: ${settings.welcomeButtons}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = WpTeal
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedButton(
                            onClick = { showEditWelcomeDialog = true },
                            modifier = Modifier.fillMaxWidth().testTag("edit_welcome_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Editar Mensagem de Boas-Vindas")
                        }
                    }
                }
            }

            // 2. Card Horário de Funcionamento & Fora de Expediente
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("hours_config_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFFEF3C7)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Schedule, contentDescription = null, tint = Color(0xFFD97706))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Horário de Atendimento",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        text = "${settings.startHour} às ${settings.endHour} (${settings.workDays})",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(
                                checked = settings.businessHoursEnabled,
                                onCheckedChange = { viewModel.updateSettings(settings.copy(businessHoursEnabled = it)) },
                                colors = SwitchDefaults.colors(checkedThumbColor = WpTeal, checkedTrackColor = WpGreen.copy(alpha = 0.5f))
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Mensagem enviada fora do expediente:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = settings.offHoursMessage,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedButton(
                            onClick = { showEditHoursDialog = true },
                            modifier = Modifier.fillMaxWidth().testTag("edit_hours_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.AccessTime, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Ajustar Horários e Mensagem")
                        }
                    }
                }
            }

            // 3. Cabeçalho de Gatilhos & Palavras-Chave
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Gatilhos por Palavras-Chave",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${triggerRules.size} automações cadastradas",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Lista de Gatilhos
            items(triggerRules) { rule ->
                TriggerRuleItem(
                    rule = rule,
                    onToggle = { viewModel.toggleRuleActive(rule) },
                    onEdit = {
                        editingRule = rule
                        isCreatingNewRule = false
                    },
                    onDelete = { viewModel.deleteRule(rule.id) }
                )
            }
        }
    }

    // Diálogo para Editar Boas-Vindas
    if (showEditWelcomeDialog) {
        var welcomeMsgInput by remember { mutableStateOf(settings.welcomeMessage) }
        var buttonsInput by remember { mutableStateOf(settings.welcomeButtons) }
        var companyInput by remember { mutableStateOf(settings.businessName) }

        AlertDialog(
            onDismissRequest = { showEditWelcomeDialog = false },
            title = { Text("Configurar Boas-Vindas") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = companyInput,
                        onValueChange = { companyInput = it },
                        label = { Text("Nome da Empresa") },
                        modifier = Modifier.fillMaxWidth().testTag("input_company_name")
                    )
                    OutlinedTextField(
                        value = welcomeMsgInput,
                        onValueChange = { welcomeMsgInput = it },
                        label = { Text("Mensagem") },
                        supportingText = { Text("Variáveis: {saudacao}, {nome}, {empresa}") },
                        modifier = Modifier.fillMaxWidth().testTag("input_welcome_msg"),
                        minLines = 3
                    )
                    OutlinedTextField(
                        value = buttonsInput,
                        onValueChange = { buttonsInput = it },
                        label = { Text("Botões de Escolha Rápida (separados por vírgula)") },
                        modifier = Modifier.fillMaxWidth().testTag("input_welcome_buttons")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateSettings(
                            settings.copy(
                                businessName = companyInput,
                                welcomeMessage = welcomeMsgInput,
                                welcomeButtons = buttonsInput
                            )
                        )
                        showEditWelcomeDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WpTeal)
                ) {
                    Text("Salvar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditWelcomeDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Diálogo para Editar Horários
    if (showEditHoursDialog) {
        var startInput by remember { mutableStateOf(settings.startHour) }
        var endInput by remember { mutableStateOf(settings.endHour) }
        var daysInput by remember { mutableStateOf(settings.workDays) }
        var offMsgInput by remember { mutableStateOf(settings.offHoursMessage) }

        AlertDialog(
            onDismissRequest = { showEditHoursDialog = false },
            title = { Text("Horário de Atendimento") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = startInput,
                            onValueChange = { startInput = it },
                            label = { Text("Início (HH:mm)") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = endInput,
                            onValueChange = { endInput = it },
                            label = { Text("Fim (HH:mm)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = daysInput,
                        onValueChange = { daysInput = it },
                        label = { Text("Dias de Atendimento") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = offMsgInput,
                        onValueChange = { offMsgInput = it },
                        label = { Text("Mensagem Fora de Horário") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateSettings(
                            settings.copy(
                                startHour = startInput,
                                endHour = endInput,
                                workDays = daysInput,
                                offHoursMessage = offMsgInput
                            )
                        )
                        showEditHoursDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WpTeal)
                ) {
                    Text("Salvar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditHoursDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Diálogo Criar / Editar Gatilho
    editingRule?.let { rule ->
        var name by remember { mutableStateOf(rule.name) }
        var keywords by remember { mutableStateOf(rule.keywords) }
        var responseTemplate by remember { mutableStateOf(rule.responseTemplate) }
        var quickButtons by remember { mutableStateOf(rule.quickButtons) }
        var isHumanTransfer by remember { mutableStateOf(rule.actionType == TriggerActionType.TRANSF_HUMANO.name) }

        AlertDialog(
            onDismissRequest = { editingRule = null },
            title = { Text(if (isCreatingNewRule) "Novo Gatilho de Atendimento" else "Editar Gatilho") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nome do Gatilho") },
                        placeholder = { Text("Ex: Preços e Cardápio") },
                        modifier = Modifier.fillMaxWidth().testTag("input_trigger_name")
                    )
                    OutlinedTextField(
                        value = keywords,
                        onValueChange = { keywords = it },
                        label = { Text("Palavras-chave (separadas por vírgula)") },
                        placeholder = { Text("preco, quanto custa, cardapio, catalogo") },
                        modifier = Modifier.fillMaxWidth().testTag("input_trigger_keywords")
                    )
                    OutlinedTextField(
                        value = responseTemplate,
                        onValueChange = { responseTemplate = it },
                        label = { Text("Mensagem de Resposta") },
                        modifier = Modifier.fillMaxWidth().testTag("input_trigger_response"),
                        minLines = 3
                    )
                    OutlinedTextField(
                        value = quickButtons,
                        onValueChange = { quickButtons = it },
                        label = { Text("Botões Interativos (opcional)") },
                        placeholder = { Text("Ex: Ver Opções, Falar com Atendente") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Transferir para atendente humano?",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Switch(
                            checked = isHumanTransfer,
                            onCheckedChange = { isHumanTransfer = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = WpTeal)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val action = if (isHumanTransfer) {
                            TriggerActionType.TRANSF_HUMANO.name
                        } else if (quickButtons.isNotBlank()) {
                            TriggerActionType.BOTOES_RAPIDOS.name
                        } else {
                            TriggerActionType.TEXTO_SIMPLES.name
                        }

                        viewModel.saveRule(
                            rule.copy(
                                name = name,
                                keywords = keywords,
                                actionType = action,
                                responseTemplate = responseTemplate,
                                quickButtons = quickButtons
                            )
                        )
                        editingRule = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WpTeal),
                    modifier = Modifier.testTag("save_trigger_button")
                ) {
                    Text("Salvar Gatilho")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingRule = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
private fun TriggerRuleItem(
    rule: TriggerRuleEntity,
    onToggle: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().testTag("trigger_rule_item_${rule.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (rule.isActive) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(if (rule.isActive) WpGreen.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (rule.actionType == TriggerActionType.TRANSF_HUMANO.name) Icons.Default.Person else Icons.Default.SmartToy,
                            contentDescription = null,
                            tint = if (rule.isActive) WpDarkTeal else Color.Gray,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = rule.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = if (rule.isActive) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${rule.matchCount} disparos automáticos",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Switch(
                    checked = rule.isActive,
                    onCheckedChange = { onToggle() },
                    colors = SwitchDefaults.colors(checkedThumbColor = WpTeal, checkedTrackColor = WpGreen.copy(alpha = 0.5f))
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Palavras-Chave badges
            Text(
                text = "Gatilhos: ${rule.keywords}",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = WpTeal
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = rule.responseTemplate,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2
            )

            if (rule.quickButtons.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.TouchApp, contentDescription = null, tint = WpDarkTeal, modifier = Modifier.size(14.dp))
                    Text(
                        text = "Opções: ${rule.quickButtons}",
                        fontSize = 11.sp,
                        color = WpDarkTeal,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(onClick = onEdit) {
                    Icon(Icons.Default.Edit, contentDescription = "Editar", tint = WpTeal, modifier = Modifier.size(20.dp))
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Excluir", tint = Color(0xFFEF4444), modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}
