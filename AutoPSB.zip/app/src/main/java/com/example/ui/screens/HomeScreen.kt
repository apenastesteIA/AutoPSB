package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.LeadEntity
import com.example.ui.components.LeadTypeBadge
import com.example.ui.components.MetaSessionWindowBadge
import com.example.ui.components.StatCard
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BlueInfo
import com.example.ui.theme.PurpleLead
import com.example.ui.theme.WpDarkTeal
import com.example.ui.theme.WpGreen
import com.example.ui.theme.WpLightGreen
import com.example.ui.theme.WpTeal
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.AutoPsbViewModel

@Composable
fun HomeScreen(
    viewModel: AutoPsbViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val totalLeads by viewModel.totalLeadsCount.collectAsStateWithLifecycle()
    val newLeads by viewModel.newLeadsCount.collectAsStateWithLifecycle()
    val recurringLeads by viewModel.recurringLeadsCount.collectAsStateWithLifecycle()
    val returnedLeads by viewModel.returnedLeadsCount.collectAsStateWithLifecycle()
    val allLeads by viewModel.allLeads.collectAsStateWithLifecycle()

    val activeWindowLeads = allLeads.filter { it.isWindowActive() }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen_column"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Cabeçalho & Status da Conexão WhatsApp Business Cloud API
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("meta_status_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = WpDarkTeal)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "AutoPSB Atendimento",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = settings.businessName,
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = WpGreen.copy(alpha = 0.2f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(WpGreen)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Meta API Conectada",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Banner da Janela de 24 Horas
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.Black.copy(alpha = 0.25f)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = WpGreen,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Regra da Janela de 24 Horas da Meta",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Bot enviando mensagens livres, botões e listas dentro da janela ativa.",
                                    color = Color.White.copy(alpha = 0.75f),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Indicadores Principais de Leads e Retenção (KPIs)
        item {
            Text(
                text = "Métricas de Captação & Retenção",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Total de Leads",
                    value = "$totalLeads",
                    subtitle = "100% respondidos",
                    icon = Icons.Default.Group,
                    iconTint = WpTeal,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Novos Leads",
                    value = "$newLeads",
                    subtitle = "Primeiro contato",
                    icon = Icons.Default.PersonAdd,
                    iconTint = BlueInfo,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Recorrentes",
                    value = "$recurringLeads",
                    subtitle = "Clientes frequentes",
                    icon = Icons.Default.CheckCircle,
                    iconTint = WpGreen,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Retornaram",
                    value = "$returnedLeads",
                    subtitle = "Inativos > 7 dias",
                    icon = Icons.Default.Replay,
                    iconTint = PurpleLead,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 3. Barra Visual de Retenção de Clientes
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Distribuição do Público no WhatsApp",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    val total = if (totalLeads > 0) totalLeads.toFloat() else 1f
                    val newRatio = newLeads / total
                    val recurringRatio = recurringLeads / total
                    val returnedRatio = returnedLeads / total

                    // Barra segmentada
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                    ) {
                        if (newLeads > 0) {
                            Box(
                                modifier = Modifier
                                    .weight(newRatio)
                                    .fillMaxSize()
                                    .background(BlueInfo)
                            )
                        }
                        if (recurringLeads > 0) {
                            Box(
                                modifier = Modifier
                                    .weight(recurringRatio)
                                    .fillMaxSize()
                                    .background(WpGreen)
                            )
                        }
                        if (returnedLeads > 0) {
                            Box(
                                modifier = Modifier
                                    .weight(returnedRatio)
                                    .fillMaxSize()
                                    .background(PurpleLead)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LegendItem(color = BlueInfo, label = "Novos (${(newRatio * 100).toInt()}%)")
                        LegendItem(color = WpGreen, label = "Recorrentes (${(recurringRatio * 100).toInt()}%)")
                        LegendItem(color = PurpleLead, label = "Retornaram (${(returnedRatio * 100).toInt()}%)")
                    }
                }
            }
        }

        // 4. Ações Rápidas
        item {
            Text(
                text = "Ações Rápidas do Lojista",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { viewModel.selectTab(AppNavTab.SIMULATOR) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("action_simulator_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = WpTeal)
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Testar Bot", fontSize = 13.sp)
                }

                OutlinedButton(
                    onClick = { viewModel.selectTab(AppNavTab.TRIGGERS) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("action_triggers_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Automações", fontSize = 13.sp)
                }
            }
        }

        // 5. Sessões Ativas na Janela de 24 Horas da Meta
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Conversas com Janela 24h Ativa",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${activeWindowLeads.size} ativas",
                    fontSize = 12.sp,
                    color = WpTeal,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        if (activeWindowLeads.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Chat,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Nenhuma conversa na janela de 24h agora",
                            fontWeight = FontWeight.Medium,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Use o Simulador para testar um cliente novo enviando mensagem!",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(activeWindowLeads.take(4)) { lead ->
                LeadQuickItem(
                    lead = lead,
                    onClick = {
                        viewModel.selectLead(lead.id)
                        viewModel.selectTab(AppNavTab.HISTORY)
                    }
                )
            }
        }
    }
}

@Composable
private fun LegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LeadQuickItem(
    lead: LeadEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("lead_quick_item_${lead.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(WpLightGreen),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = lead.name.take(1).uppercase(),
                    color = WpDarkTeal,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = lead.name,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                    LeadTypeBadge(leadType = lead.leadType)
                }
                Spacer(modifier = Modifier.height(3.dp))
                MetaSessionWindowBadge(lead = lead)
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Abrir conversa",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
