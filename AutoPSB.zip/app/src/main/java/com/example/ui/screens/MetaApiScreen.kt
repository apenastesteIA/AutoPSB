package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.WpDarkTeal
import com.example.ui.theme.WpGreen
import com.example.ui.theme.WpTeal
import com.example.ui.viewmodel.AutoPsbViewModel

@Composable
fun MetaApiScreen(
    viewModel: AutoPsbViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    var phoneId by remember(settings) { mutableStateOf(settings.metaPhoneNumberId) }
    var wabaId by remember(settings) { mutableStateOf(settings.metaWabaId) }
    var token by remember(settings) { mutableStateOf(settings.metaAccessToken) }
    var verifyToken by remember(settings) { mutableStateOf(settings.metaWebhookVerifyToken) }
    var webhookUrl by remember(settings) { mutableStateOf(settings.metaWebhookUrl) }
    var savedSuccess by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("meta_api_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Título & Status Oficial Meta
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = WpDarkTeal)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(WpGreen),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.CloudDone, contentDescription = null, tint = WpDarkTeal)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "WhatsApp Business Cloud API",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "Integração Oficial da Meta (Graph API v21.0)",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Todas as conversas respeitam rigorosamente a janela de 24 horas da Meta e suportam mensagens interativas, botões e listas.",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Credenciais da Meta Cloud API
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Credenciais do WhatsApp na Meta",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = phoneId,
                        onValueChange = { phoneId = it; savedSuccess = false },
                        label = { Text("Phone Number ID") },
                        leadingIcon = { Icon(Icons.Default.Key, contentDescription = null, tint = WpTeal) },
                        modifier = Modifier.fillMaxWidth().testTag("meta_phone_id_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = wabaId,
                        onValueChange = { wabaId = it; savedSuccess = false },
                        label = { Text("WABA ID (WhatsApp Business Account ID)") },
                        leadingIcon = { Icon(Icons.Default.Hub, contentDescription = null, tint = WpTeal) },
                        modifier = Modifier.fillMaxWidth().testTag("meta_waba_id_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = token,
                        onValueChange = { token = it; savedSuccess = false },
                        label = { Text("Token de Acesso Permanente da Meta") },
                        leadingIcon = { Icon(Icons.Default.VpnKey, contentDescription = null, tint = WpTeal) },
                        modifier = Modifier.fillMaxWidth().testTag("meta_token_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = verifyToken,
                        onValueChange = { verifyToken = it; savedSuccess = false },
                        label = { Text("Webhook Verify Token") },
                        leadingIcon = { Icon(Icons.Default.Security, contentDescription = null, tint = WpTeal) },
                        modifier = Modifier.fillMaxWidth().testTag("meta_verify_token_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = webhookUrl,
                        onValueChange = { webhookUrl = it; savedSuccess = false },
                        label = { Text("Webhook URL de Callback") },
                        modifier = Modifier.fillMaxWidth().testTag("meta_webhook_url_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            viewModel.updateSettings(
                                settings.copy(
                                    metaPhoneNumberId = phoneId,
                                    metaWabaId = wabaId,
                                    metaAccessToken = token,
                                    metaWebhookVerifyToken = verifyToken,
                                    metaWebhookUrl = webhookUrl
                                )
                            )
                            savedSuccess = true
                        },
                        modifier = Modifier.fillMaxWidth().testTag("save_meta_creds_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = WpTeal)
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (savedSuccess) "Credenciais Salvas com Sucesso!" else "Salvar Credenciais da Meta")
                    }
                }
            }
        }

        // Arquitetura do Backend Node.js
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Code, contentDescription = null, tint = WpTeal)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Backend Node.js & Endpoints REST",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "O AutoPSB inclui a estrutura de servidor Node.js pronta em /backend-nodejs com os seguintes endpoints:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF0F172A),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            EndpointDoc(method = "GET", path = "/webhook", desc = "Validação do Token Meta Cloud API")
                            Spacer(modifier = Modifier.height(6.dp))
                            EndpointDoc(method = "POST", path = "/webhook", desc = "Recebimento de mensagens do cliente")
                            Spacer(modifier = Modifier.height(6.dp))
                            EndpointDoc(method = "GET", path = "/api/leads", desc = "Lista de leads (Novos, Recorrentes, Retorno)")
                            Spacer(modifier = Modifier.height(6.dp))
                            EndpointDoc(method = "GET", path = "/api/triggers", desc = "Regras e palavras-chave de automação")
                            Spacer(modifier = Modifier.height(6.dp))
                            EndpointDoc(method = "GET", path = "/api/stats", desc = "KPIs de conversão e retenção")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EndpointDoc(method: String, path: String, desc: String) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = method,
                color = if (method == "GET") Color(0xFF60A5FA) else Color(0xFF4ADE80),
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = path,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        Text(text = desc, color = Color.Gray, fontSize = 10.sp)
    }
}
