package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.WhatsAppTypingIndicator
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.WpDarkTeal
import com.example.ui.theme.WpGreen
import com.example.ui.theme.WpTeal
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.AutoPsbViewModel

@Composable
fun SimulatorScreen(
    viewModel: AutoPsbViewModel,
    modifier: Modifier = Modifier
) {
    var phoneInput by remember { mutableStateOf("+55 11 98888-7777") }
    var nameInput by remember { mutableStateOf("Lucas Fernandes") }
    var messageInput by remember { mutableStateOf("Olá, qual é o cardápio e os preços de vocês?") }
    var lastSimulatedLeadId by remember { mutableStateOf<Long?>(null) }

    val isTyping by viewModel.isSimulatingTyping.collectAsStateWithLifecycle()
    val statusMessage by viewModel.simulatorStatus.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("simulator_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Título & Instruções
        item {
            Column {
                Text(
                    text = "Simulador WhatsApp Business",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Teste como o AutoPSB recebe mensagens da Meta Cloud API, dispara gatilhos e classifica os clientes em tempo real.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Cenários Prontos para Teste Rápido
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Bolt, contentDescription = null, tint = WpTeal, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Testes Rápidos de Cenários de Clientes",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        PresetButton(
                            title = "Novo Lead perguntando Preço",
                            subtitle = "Gera lead NOVO + dispara gatilho de cardápio",
                            onClick = {
                                phoneInput = "+55 11 91234-5678"
                                nameInput = "Camila Rocha"
                                messageInput = "Boa tarde! Gostaria de saber os preços e cardápio de hoje."
                            }
                        )
                        PresetButton(
                            title = "Cliente Recorrente pedindo PIX",
                            subtitle = "Gera lead RECORRENTE + dados de pagamento",
                            onClick = {
                                phoneInput = "+55 11 97123-8899"
                                nameInput = "Rodrigo Mendes"
                                messageInput = "Oi pessoal, me manda a chave PIX para eu pagar."
                            }
                        )
                        PresetButton(
                            title = "Cliente que Retornou após 20 dias",
                            subtitle = "Gera lead RETORNOU + saudação calorosa de boas-vindas",
                            onClick = {
                                phoneInput = "+55 11 96543-2100"
                                nameInput = "Juliana Costa"
                                messageInput = "Olá! Quanto tempo! Quero fazer uma nova encomenda."
                            }
                        )
                        PresetButton(
                            title = "Solicitação de Atendente Humano",
                            subtitle = "Dispara gatilho de transição para humano",
                            onClick = {
                                phoneInput = "+55 11 99876-1122"
                                nameInput = "Fernando Dias"
                                messageInput = "Preciso falar urgente com um atendente humano."
                            }
                        )
                    }
                }
            }
        }

        // Formulário do Simulador
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("simulation_form_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Dados da Mensagem Recebida",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        label = { Text("Número do WhatsApp do Cliente") },
                        leadingIcon = { Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = WpTeal) },
                        modifier = Modifier.fillMaxWidth().testTag("simulator_phone_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Nome do Cliente (identificado no WhatsApp)") },
                        modifier = Modifier.fillMaxWidth().testTag("simulator_name_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = messageInput,
                        onValueChange = { messageInput = it },
                        label = { Text("Texto da Mensagem Recebida") },
                        modifier = Modifier.fillMaxWidth().testTag("simulator_message_input"),
                        minLines = 3
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Botão de Envio
                    Button(
                        onClick = {
                            viewModel.simulateIncomingWhatsAppMessage(
                                phone = phoneInput,
                                name = nameInput,
                                message = messageInput,
                                onComplete = { leadId ->
                                    lastSimulatedLeadId = leadId
                                }
                            )
                        },
                        modifier = Modifier.fillMaxWidth().testTag("simulate_send_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = WpGreen),
                        enabled = !isTyping && messageInput.isNotBlank()
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isTyping) "Processando automação..." else "Simular Envio no WhatsApp",
                            fontWeight = FontWeight.Bold,
                            color = WpDarkTeal
                        )
                    }
                }
            }
        }

        // Feedback em Tempo Real da Automação
        if (isTyping || statusMessage != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("simulator_status_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = WpDarkTeal)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (isTyping) {
                            WhatsAppTypingIndicator()
                            Spacer(modifier = Modifier.height(10.dp))
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(WpGreen),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = WpDarkTeal)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                        }

                        Text(
                            text = statusMessage ?: "Executando...",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )

                        if (!isTyping && lastSimulatedLeadId != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    viewModel.selectLead(lastSimulatedLeadId)
                                    viewModel.selectTab(AppNavTab.HISTORY)
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = WpGreen)
                            ) {
                                Text("Ver Conversa no Histórico", color = WpDarkTeal, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = WpDarkTeal, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PresetButton(
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                Text(text = subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedButton(
                onClick = onClick,
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text("Carregar", fontSize = 11.sp, color = WpTeal)
            }
        }
    }
}
