package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AutoPsbDatabase
import com.example.data.model.BusinessSettingsEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.LeadEntity
import com.example.data.model.LeadStatus
import com.example.data.model.TriggerRuleEntity
import com.example.data.repository.AutoPsbRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppNavTab(val title: String) {
    HOME("Home"),
    TRIGGERS("Configuração"),
    HISTORY("Histórico"),
    SIMULATOR("Simulador"),
    META_API("Meta Cloud API")
}

class AutoPsbViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AutoPsbRepository

    init {
        val database = AutoPsbDatabase.getDatabase(application, viewModelScope)
        repository = AutoPsbRepository(
            database.leadDao(),
            database.chatMessageDao(),
            database.triggerRuleDao(),
            database.businessSettingsDao()
        )
    }

    // Navegação principal
    private val _currentTab = MutableStateFlow(AppNavTab.HOME)
    val currentTab: StateFlow<AppNavTab> = _currentTab.asStateFlow()

    fun selectTab(tab: AppNavTab) {
        _currentTab.value = tab
    }

    // Leads & Filtros
    val allLeads: StateFlow<List<LeadEntity>> = repository.allLeads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _leadFilter = MutableStateFlow("TODOS") // TODOS, NOVO, RECORRENTE, RETORNOU, AGUARDANDO_HUMANO
    val leadFilter: StateFlow<String> = _leadFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val filteredLeads: StateFlow<List<LeadEntity>> = combine(allLeads, _leadFilter, _searchQuery) { leads, filter, query ->
        leads.filter { lead ->
            val matchesFilter = when (filter) {
                "NOVO" -> lead.leadType == "NOVO"
                "RECORRENTE" -> lead.leadType == "RECORRENTE"
                "RETORNOU" -> lead.leadType == "RETORNOU"
                "AGUARDANDO_HUMANO" -> lead.status == LeadStatus.AGUARDANDO_HUMANO.name
                else -> true
            }
            val matchesQuery = query.isBlank() ||
                lead.name.contains(query, ignoreCase = true) ||
                lead.phoneNumber.contains(query, ignoreCase = true) ||
                lead.tags.contains(query, ignoreCase = true)

            matchesFilter && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Lead Selecionado para Chat
    private val _selectedLeadId = MutableStateFlow<Long?>(null)
    val selectedLeadId: StateFlow<Long?> = _selectedLeadId.asStateFlow()

    val selectedLead: StateFlow<LeadEntity?> = _selectedLeadId.flatMapLatest { id ->
        if (id == null) flowOf(null) else repository.getLeadById(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentChatMessages: StateFlow<List<ChatMessageEntity>> = _selectedLeadId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else repository.getMessagesForLead(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectLead(leadId: Long?) {
        _selectedLeadId.value = leadId
    }

    // Regras de Automação / Gatilhos
    val triggerRules: StateFlow<List<TriggerRuleEntity>> = repository.allRules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Configurações do Negócio
    val settings: StateFlow<BusinessSettingsEntity> = repository.settings
        .flatMapLatest { it?.let { flowOf(it) } ?: flowOf(BusinessSettingsEntity()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BusinessSettingsEntity())

    // KPIs & Contadores
    val totalLeadsCount: StateFlow<Int> = repository.totalLeadsCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val newLeadsCount: StateFlow<Int> = repository.newLeadsCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val recurringLeadsCount: StateFlow<Int> = repository.recurringLeadsCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val returnedLeadsCount: StateFlow<Int> = repository.returnedLeadsCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Estado do Simulador de WhatsApp
    private val _isSimulatingTyping = MutableStateFlow(false)
    val isSimulatingTyping: StateFlow<Boolean> = _isSimulatingTyping.asStateFlow()

    private val _simulatorStatus = MutableStateFlow<String?>(null)
    val simulatorStatus: StateFlow<String?> = _simulatorStatus.asStateFlow()

    fun setLeadFilter(filter: String) {
        _leadFilter.value = filter
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Ações de Regras
    fun saveRule(rule: TriggerRuleEntity) {
        viewModelScope.launch {
            repository.saveRule(rule)
        }
    }

    fun toggleRuleActive(rule: TriggerRuleEntity) {
        viewModelScope.launch {
            repository.saveRule(rule.copy(isActive = !rule.isActive))
        }
    }

    fun deleteRule(ruleId: Long) {
        viewModelScope.launch {
            repository.deleteRule(ruleId)
        }
    }

    // Ações de Configurações
    fun updateSettings(newSettings: BusinessSettingsEntity) {
        viewModelScope.launch {
            repository.updateSettings(newSettings)
        }
    }

    // Enviar mensagem manual como Atendente
    fun sendAgentReply(leadId: Long, text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            repository.sendManualAgentReply(leadId, text)
        }
    }

    // Simulador: Simula cliente enviando mensagem pelo WhatsApp
    fun simulateIncomingWhatsAppMessage(
        phone: String,
        name: String,
        message: String,
        onComplete: (Long) -> Unit
    ) {
        if (message.isBlank()) return
        viewModelScope.launch {
            _simulatorStatus.value = "Mensagem recebida no webhook da Meta Cloud API..."
            val leadId = repository.processIncomingWhatsAppMessage(
                phoneNumber = phone.ifBlank { "+55 11 99999-0000" },
                senderName = name.ifBlank { "Cliente WhatsApp" },
                messageContent = message,
                onTypingStateChanged = { isTyping ->
                    _isSimulatingTyping.value = isTyping
                    if (isTyping) {
                        _simulatorStatus.value = "AutoPSB humanizado: Bot está digitando resposta..."
                    } else {
                        _simulatorStatus.value = "Resposta entregue ao cliente via WhatsApp!"
                    }
                }
            )
            onComplete(leadId)
        }
    }

    fun clearSimulatorStatus() {
        _simulatorStatus.value = null
    }
}
