package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// AutoPSB Emerald & WhatsApp Business Palette
val WpDarkTeal = Color(0xFF075E54)
val WpTeal = Color(0xFF128C7E)
val WpGreen = Color(0xFF25D366)
val WpLightGreen = Color(0xFFDCF8C6)
val WpChatBubbleUser = Color(0xFFE7FFDB)
val WpChatBubbleOther = Color(0xFFFFFFFF)
val WpBackgroundLight = Color(0xFFF0F4F2)
val WpChatBackground = Color(0xFFEFEAE2)

// Accent & Status Colors
val AmberWarning = Color(0xFFF59E0B)
val RedDanger = Color(0xFFEF4444)
val BlueInfo = Color(0xFF3B82F6)
val PurpleLead = Color(0xFF8B5CF6)
val Slate700 = Color(0xFF334155)
val Slate900 = Color(0xFF0F172A)
val Slate100 = Color(0xFFF1F5F9)
val GrayBorder = Color(0xFFE2E8F0)

// Material 3 Tokens - Light
val LightPrimary = Color(0xFF075E54)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFD4F5E9)
val LightOnPrimaryContainer = Color(0xFF00382E)
val LightSecondary = Color(0xFF128C7E)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightSecondaryContainer = Color(0xFFC7EDE6)
val LightOnSecondaryContainer = Color(0xFF003730)
val LightTertiary = Color(0xFF25D366)
val LightBackground = Color(0xFFF8FAF9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEBF1EE)
val LightOnSurface = Color(0xFF1A1C1B)
val LightOnSurfaceVariant = Color(0xFF404945)

// Material 3 Tokens - Dark
val DarkPrimary = Color(0xFF4EE2BD)
val DarkOnPrimary = Color(0xFF00382E)
val DarkPrimaryContainer = Color(0xFF075E54)
val DarkOnPrimaryContainer = Color(0xFFD4F5E9)
val DarkSecondary = Color(0xFF80D5C7)
val DarkOnSecondary = Color(0xFF003730)
val DarkSecondaryContainer = Color(0xFF128C7E)
val DarkBackground = Color(0xFF111B21)
val DarkSurface = Color(0xFF1F2C34)
val DarkSurfaceVariant = Color(0xFF2A3942)
val DarkOnSurface = Color(0xFFE9EDEF)
val DarkOnSurfaceVariant = Color(0xFF8696A0)
