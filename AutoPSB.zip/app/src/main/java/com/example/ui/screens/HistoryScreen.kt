package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ChatMessageEntity
import com.example.data.model.LeadEntity
import com.example.data.model.MessageSender
import com.example.ui.components.LeadTypeBadge
import com.example.ui.components.MetaSessionWindowBadge
import com.example.ui.theme.RedDanger
import com.example.ui.theme.WpChatBackground
import com.example.ui.theme.WpChatBubbleOther
import com.example.ui.theme.WpChatBubbleUser
import com.example.ui.theme.WpDarkTeal
import com.example.ui.theme.WpGreen
import com.example.ui.theme.WpLightGreen
import com.example.ui.theme.WpTeal
import com.example.ui.viewmodel.AutoPsbViewModel

@Composable
fun HistoryScreen(
    viewModel: AutoPsbViewModel,
    modifier: Modifier = Modifier
) {
    val selectedLeadId by viewModel.selectedLeadId.collectAsStateWithLifecycle()
    val selectedLead by viewModel.selectedLead.collectAsStateWithLifecycle()
    val chatMessages by viewModel.currentChatMessages.collectAsStateWithLifecycle()

    if (selectedLeadId != null && selectedLead != null) {
        // Exibe o Chat detalhado
        ConversationDetailView(
            lead = selectedLead!!,
            messages = chatMessages,
            onBack = { viewModel.selectLead(null) },
            onSendReply = { text -> viewModel.sendAgentReply(selectedLead!!.id, text) },
            modifier = modifier
        )
    } else {
        // Exibe a Lista de Conversas
        ConversationListView(
            viewModel = viewModel,
            onSelectLead = { leadId -> viewModel.selectLead(leadId) },
            modifier = modifier
        )
    }
}

@Composable
private fun ConversationListView(
    viewModel: AutoPsbViewModel,
    onSelectLead: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val filteredLeads by viewModel.filteredLeads.collectAsStateWithLifecycle()
    val activeFilter by viewModel.leadFilter.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("conversation_list_screen")
    ) {
        // Cabeçalho & Barra de Pesquisa
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Histórico de Atendimento",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Pesquise conversas e acompanhe leads novos, recorrentes e de retorno.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text("Pesquisar por nome, telefone ou tags...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = WpTeal) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("history_search_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = WpTeal,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Filtros rápidos
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val filters = listOf(
                    "TODOS" to "Todos",
                    "NOVO" to "Novos",
                    "RECORRENTE" to "Recorrentes",
                    "RETORNOU" to "Retornaram",
                    "AGUARDANDO_HUMANO" to "Precisa de Humano"
                )
                items(filters) { (key, label) ->
                    FilterChip(
                        selected = activeFilter == key,
                        onClick = { viewModel.setLeadFilter(key) },
                        label = { Text(label, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = WpTeal,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        // Lista de Leads
        if (filteredLeads.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Chat,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Nenhuma conversa encontrada",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "Tente alterar o filtro ou simular uma nova mensagem no Simulador.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredLeads, key = { it.id }) { lead ->
                    ConversationItemCard(lead = lead, onClick = { onSelectLead(lead.id) })
                }
            }
        }
    }
}

@Composable
private fun ConversationItemCard(
    lead: LeadEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("conversation_card_${lead.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(WpTeal.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = lead.name.take(1).uppercase(),
                    color = WpDarkTeal,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = lead.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = lead.formattedLastContact(),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = lead.phoneNumber,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LeadTypeBadge(leadType = lead.leadType)
                    MetaSessionWindowBadge(lead = lead)
                }
            }
        }
    }
}

@Composable
private fun ConversationDetailView(
    lead: LeadEntity,
    messages: List<ChatMessageEntity>,
    onBack: () -> Unit,
    onSendReply: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }
    var replyText by remember { mutableStateOf("") }
    val isWindowActive = lead.isWindowActive()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WpChatBackground)
            .testTag("conversation_detail_screen")
    ) {
        // Header do Chat com Informações do Lead & Janela 24h
        Surface(
            color = WpDarkTeal,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("chat_back_button")) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Voltar", tint = Color.White)
                }

                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(WpGreen),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = lead.name.take(1).uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = lead.name,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        LeadTypeBadge(leadType = lead.leadType)
                    }
                    Text(
                        text = "${lead.phoneNumber} • ${lead.formattedRemainingWindow()}",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Alerta da Janela de 24h caso expirada
        if (!isWindowActive) {
            Surface(
                color = Color(0xFFFEF2F2),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = RedDanger, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Janela de 24h Meta encerrada. Para enviar novas mensagens ativas, as regras do WhatsApp exigem Template aprovado pela Meta.",
                        color = RedDanger,
                        fontSize = 11.sp,
                        lineHeight = 14.sp
                    )
                }
            }
        }

        // Histórico de Mensagens
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages, key = { it.id }) { message ->
                MessageBubble(message = message)
            }
        }

        // Barra de Envio de Mensagem (Intervenção Humana)
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = replyText,
                    onValueChange = { replyText = it },
                    placeholder = {
                        Text(
                            if (isWindowActive) "Escreva uma resposta humanizada..."
                            else "Enviar modelo de mensagem aprovado..."
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_text"),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = WpTeal,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    maxLines = 3
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (replyText.isNotBlank()) {
                            onSendReply(replyText)
                            replyText = ""
                        }
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(WpTeal)
                        .testTag("send_reply_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Enviar",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessageEntity) {
    val isFromClient = message.sender == MessageSender.CLIENTE.name
    val isFromBot = message.sender == MessageSender.BOT.name

    val alignment = if (isFromClient) Alignment.Start else Alignment.End
    val bubbleColor = if (isFromClient) WpChatBubbleOther else WpChatBubbleUser
    val bubbleShape = if (isFromClient) {
        RoundedCornerShape(topStart = 0.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
    } else {
        RoundedCornerShape(topStart = 16.dp, topEnd = 0.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = alignment
    ) {
        Surface(
            color = bubbleColor,
            shape = bubbleShape,
            shadowElevation = 1.dp,
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                // Header com indicação de quem enviou
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (isFromBot) {
                        Icon(
                            imageVector = Icons.Default.SmartToy,
                            contentDescription = null,
                            tint = WpTeal,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "AutoPSB (Bot)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = WpTeal
                        )
                    } else if (!isFromClient) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = WpDarkTeal,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Atendente Humano",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = WpDarkTeal
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = message.content,
                    fontSize = 14.sp,
                    color = Color(0xFF1E293B),
                    lineHeight = 18.sp
                )

                // Botões de Ação Rápida caso presentes
                if (message.quickOptions.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        message.quickOptions.split(",").map { it.trim() }.filter { it.isNotBlank() }.forEach { opt ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = WpLightGreen.copy(alpha = 0.7f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "👉 $opt",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = WpDarkTeal,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (message.triggerMatched != null) {
                        Text(
                            text = "[Gatilho: ${message.triggerMatched}] ",
                            fontSize = 9.sp,
                            color = Color.Gray
                        )
                    }
                    Text(
                        text = message.formattedTime(),
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                    if (!isFromClient) {
                        Spacer(modifier = Modifier.width(3.dp))
                        Icon(
                            imageVector = Icons.Default.DoneAll,
                            contentDescription = "Entregue",
                            tint = WpTeal,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}
