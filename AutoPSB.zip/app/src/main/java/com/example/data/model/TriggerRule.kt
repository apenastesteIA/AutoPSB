package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TriggerActionType(val label: String) {
    TEXTO_SIMPLES("Mensagem Humanizada"),
    BOTOES_RAPIDOS("Mensagem com Botões de Escolha"),
    LISTA_OPCOES("Menu / Lista Interativa"),
    TRANSF_HUMANO("Transferir para Atendente Humano")
}

@Entity(tableName = "trigger_rules")
data class TriggerRuleEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val keywords: String, // Comma-separated: "preco, valor, cardapio, quanto custa"
    val actionType: String = TriggerActionType.TEXTO_SIMPLES.name,
    val responseTemplate: String,
    val quickButtons: String = "", // e.g. "Ver Cardápio, Falar com Atendente, Fazer Pedido"
    val delaySeconds: Int = 2, // Natural humanized typing delay
    val includeGreeting: Boolean = true, // Insere Bom dia / Boa tarde automaticamente
    val isActive: Boolean = true,
    val matchCount: Int = 0
)
