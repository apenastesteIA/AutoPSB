package com.example.data.repository

import com.example.data.local.BusinessSettingsDao
import com.example.data.local.ChatMessageDao
import com.example.data.local.LeadDao
import com.example.data.local.TriggerRuleDao
import com.example.data.model.BusinessSettingsEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.LeadEntity
import com.example.data.model.LeadStatus
import com.example.data.model.LeadType
import com.example.data.model.MessageSender
import com.example.data.model.TriggerRuleEntity
import com.example.engine.WhatsAppAutomationEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class AutoPsbRepository(
    private val leadDao: LeadDao,
    private val chatMessageDao: ChatMessageDao,
    private val triggerRuleDao: TriggerRuleDao,
    private val settingsDao: BusinessSettingsDao
) {
    val allLeads: Flow<List<LeadEntity>> = leadDao.getAllLeads()
    val allRules: Flow<List<TriggerRuleEntity>> = triggerRuleDao.getAllRules()
    val settings: Flow<BusinessSettingsEntity?> = settingsDao.getSettings()

    val totalLeadsCount: Flow<Int> = leadDao.getTotalLeadsCount()
    val newLeadsCount: Flow<Int> = leadDao.getNewLeadsCount()
    val recurringLeadsCount: Flow<Int> = leadDao.getRecurringLeadsCount()
    val returnedLeadsCount: Flow<Int> = leadDao.getReturnedLeadsCount()

    fun getMessagesForLead(leadId: Long): Flow<List<ChatMessageEntity>> =
        chatMessageDao.getMessagesForLead(leadId)

    fun getLeadById(leadId: Long): Flow<LeadEntity?> =
        leadDao.getLeadById(leadId)

    suspend fun getSettingsSync(): BusinessSettingsEntity {
        return settingsDao.getSettingsSync() ?: BusinessSettingsEntity()
    }

    suspend fun updateSettings(settings: BusinessSettingsEntity) {
        settingsDao.insertOrUpdate(settings)
    }

    suspend fun saveRule(rule: TriggerRuleEntity) {
        if (rule.id == 0L) {
            triggerRuleDao.insertRule(rule)
        } else {
            triggerRuleDao.updateRule(rule)
        }
    }

    suspend fun deleteRule(ruleId: Long) {
        triggerRuleDao.deleteRuleById(ruleId)
    }

    suspend fun updateLeadStatus(leadId: Long, status: LeadStatus) {
        val lead = leadDao.getLeadById(leadId).firstOrNull() ?: return
        leadDao.updateLead(lead.copy(status = status.name))
    }

    /**
     * Envia uma resposta manual escrita pelo atendente humano do pequeno comércio.
     */
    suspend fun sendManualAgentReply(leadId: Long, text: String) {
        val lead = leadDao.getLeadById(leadId).firstOrNull() ?: return
        val now = System.currentTimeMillis()

        chatMessageDao.insertMessage(
            ChatMessageEntity(
                leadId = leadId,
                sender = MessageSender.ATENDENTE.name,
                content = text,
                timestamp = now,
                type = "TEXTO",
                isDelivered = true
            )
        )

        leadDao.updateLead(
            lead.copy(
                lastInteractionTimestamp = now,
                messageCount = lead.messageCount + 1,
                status = LeadStatus.RESPONDIDO.name
            )
        )
    }

    /**
     * Processa uma mensagem recebida do WhatsApp (seja via Webhook da Meta Cloud API ou pelo Simulador do App).
     * Aplica o algoritmo de classificação de leads (Novo, Recorrente, Retornou),
     * computa a Janela de 24h, busca regras ativas e despacha a resposta humanizada do bot com delay.
     */
    suspend fun processIncomingWhatsAppMessage(
        phoneNumber: String,
        senderName: String,
        messageContent: String,
        onTypingStateChanged: ((Boolean) -> Unit)? = null
    ): Long {
        val now = System.currentTimeMillis()
        val currentSettings = getSettingsSync()
        val existingLead = leadDao.getLeadByPhone(phoneNumber)

        // 1. Classificação do Lead (Novo, Recorrente ou Retornou)
        val classifiedType = WhatsAppAutomationEngine.classifyLead(existingLead, now)

        val leadId: Long = if (existingLead == null) {
            // Novo Lead captado
            leadDao.insertLead(
                LeadEntity(
                    phoneNumber = phoneNumber,
                    name = senderName.ifBlank { "Cliente WhatsApp" },
                    leadType = classifiedType.name,
                    firstInteractionTimestamp = now,
                    lastInteractionTimestamp = now,
                    lastCustomerMessageTimestamp = now,
                    messageCount = 1,
                    status = LeadStatus.EM_ATENDIMENTO.name,
                    tags = "Novo Contato"
                )
            )
        } else {
            // Atualizar lead existente
            val updated = existingLead.copy(
                name = if (senderName.isNotBlank() && existingLead.name == "Cliente WhatsApp") senderName else existingLead.name,
                leadType = classifiedType.name,
                lastInteractionTimestamp = now,
                lastCustomerMessageTimestamp = now, // Reinicia os 24h da sessão da Meta!
                messageCount = existingLead.messageCount + 1,
                status = LeadStatus.EM_ATENDIMENTO.name
            )
            leadDao.updateLead(updated)
            existingLead.id
        }

        // 2. Salva a mensagem recebida do cliente
        chatMessageDao.insertMessage(
            ChatMessageEntity(
                leadId = leadId,
                sender = MessageSender.CLIENTE.name,
                content = messageContent,
                timestamp = now,
                type = "TEXTO"
            )
        )

        // 3. Processa regras e automação
        val activeRules = triggerRuleDao.getActiveRulesSync()
        val response = WhatsAppAutomationEngine.processIncomingMessage(
            messageContent = messageContent,
            leadName = senderName.ifBlank { "Cliente" },
            leadType = classifiedType,
            activeRules = activeRules,
            settings = currentSettings
        )

        // Simula o tempo de digitação humanizado ("Digitando...")
        if (response.isHandledByBot) {
            onTypingStateChanged?.invoke(true)
            delay(response.delayMs)
            onTypingStateChanged?.invoke(false)

            // Salva a resposta do bot
            val botTimestamp = System.currentTimeMillis()
            chatMessageDao.insertMessage(
                ChatMessageEntity(
                    leadId = leadId,
                    sender = MessageSender.BOT.name,
                    content = response.replyText,
                    timestamp = botTimestamp,
                    type = response.messageType,
                    quickOptions = response.quickButtons,
                    triggerMatched = response.triggerMatched,
                    humanizationDelayMs = response.delayMs
                )
            )

            // Atualiza status do lead
            val leadAfterReply = leadDao.getLeadById(leadId).firstOrNull()
            if (leadAfterReply != null) {
                val newStatus = if (response.requiresHumanAttention) {
                    LeadStatus.AGUARDANDO_HUMANO
                } else {
                    LeadStatus.RESPONDIDO
                }
                leadDao.updateLead(
                    leadAfterReply.copy(
                        lastInteractionTimestamp = botTimestamp,
                        messageCount = leadAfterReply.messageCount + 1,
                        status = newStatus.name
                    )
                )
            }
        }

        return leadId
    }
}
