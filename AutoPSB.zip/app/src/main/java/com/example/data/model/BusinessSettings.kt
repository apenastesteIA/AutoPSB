package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "business_settings")
data class BusinessSettingsEntity(
    @PrimaryKey
    val id: Int = 1,
    val businessName: String = "Meu Comércio",
    // Automação de Boas-Vindas
    val welcomeEnabled: Boolean = true,
    val welcomeMessage: String = "{saudacao}! Bem-vindo(a) à {empresa}. Como podemos te ajudar hoje? Digite sua dúvida ou escolha uma das opções abaixo.",
    val welcomeButtons: String = "Ver Produtos, Preços e Ofertas, Falar com Atendente",
    // Horário de Funcionamento
    val businessHoursEnabled: Boolean = true,
    val startHour: String = "08:00",
    val endHour: String = "18:00",
    val workDays: String = "Segunda a Sexta", // e.g. "Segunda a Sábado"
    val offHoursMessage: String = "Olá! No momento estamos fora do nosso horário de atendimento (Seg a Sex das 08h às 18h). Deixe sua mensagem que responderemos logo no início do expediente!",
    // Humanização
    val humanizedDelayEnabled: Boolean = true,
    val minDelaySeconds: Int = 2,
    val maxDelaySeconds: Int = 4,
    val showTypingStatus: Boolean = true,
    // Conexão Meta WhatsApp Business Cloud API
    val metaPhoneNumberId: String = "104829104812345",
    val metaWabaId: String = "982340129841234",
    val metaAccessToken: String = "EAAG...MetaCloudApiToken",
    val metaWebhookVerifyToken: String = "autopsb_verify_token_2025",
    val metaWebhookUrl: String = "https://api.autopsb.com/webhook",
    val isApiConnected: Boolean = true
)
