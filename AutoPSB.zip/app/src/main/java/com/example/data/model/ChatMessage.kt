package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class MessageSender(val label: String) {
    CLIENTE("Cliente"),
    BOT("AutoPSB Bot"),
    ATENDENTE("Atendente Humano")
}

enum class MessageType {
    TEXTO,
    BOTOES,
    LISTA,
    AVISO_JANELA
}

@Entity(
    tableName = "chat_messages",
    foreignKeys = [
        ForeignKey(
            entity = LeadEntity::class,
            parentColumns = ["id"],
            childColumns = ["leadId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["leadId"]), Index(value = ["timestamp"])]
)
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val leadId: Long,
    val sender: String = MessageSender.CLIENTE.name,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val type: String = MessageType.TEXTO.name,
    val quickOptions: String = "", // Comma-separated or JSON list of buttons
    val triggerMatched: String? = null,
    val humanizationDelayMs: Long = 0L,
    val isDelivered: Boolean = true
) {
    fun formattedTime(): String {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }
}
