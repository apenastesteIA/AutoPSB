package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class LeadType(val label: String, val description: String) {
    NOVO("Novo Lead", "Primeiro contato com a empresa"),
    RECORRENTE("Recorrente", "Cliente habitual com contatos frequentes"),
    RETORNOU("Retornou", "Voltou a falar após mais de 7 dias inativo")
}

enum class LeadStatus(val label: String) {
    EM_ATENDIMENTO("Em Atendimento"),
    RESPONDIDO("Respondido pelo Bot"),
    AGUARDANDO_HUMANO("Aguardando Atendente"),
    CONVERTIDO("Venda/Lead Convertido"),
    FINALIZADO("Finalizado")
}

@Entity(tableName = "leads")
data class LeadEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val phoneNumber: String,
    val name: String,
    val leadType: String = LeadType.NOVO.name,
    val firstInteractionTimestamp: Long = System.currentTimeMillis(),
    val lastInteractionTimestamp: Long = System.currentTimeMillis(),
    val lastCustomerMessageTimestamp: Long = System.currentTimeMillis(),
    val messageCount: Int = 1,
    val status: String = LeadStatus.RESPONDIDO.name,
    val tags: String = "Interessado",
    val notes: String = "",
    val averageResponseTimeSeconds: Int = 3
) {
    /**
     * Calcula o tempo restante da Janela de 24 Horas da Meta Cloud API.
     * Retorna o tempo em milissegundos restantes ou 0 se a janela expirou.
     */
    fun remainingSessionWindowMillis(): Long {
        val windowLimit = 24 * 60 * 60 * 1000L // 24 horas
        val elapsed = System.currentTimeMillis() - lastCustomerMessageTimestamp
        val remaining = windowLimit - elapsed
        return if (remaining > 0) remaining else 0L
    }

    fun isWindowActive(): Boolean = remainingSessionWindowMillis() > 0

    fun formattedRemainingWindow(): String {
        val remaining = remainingSessionWindowMillis()
        if (remaining <= 0) return "Janela Expirada (Exige Template)"
        val hours = remaining / (1000 * 60 * 60)
        val minutes = (remaining / (1000 * 60)) % 60
        return "${hours}h ${minutes}min restantes"
    }

    fun formattedLastContact(): String {
        val sdf = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
        return sdf.format(Date(lastInteractionTimestamp))
    }
}
