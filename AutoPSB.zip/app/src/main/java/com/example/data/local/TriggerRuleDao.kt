package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.TriggerRuleEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TriggerRuleDao {
    @Query("SELECT * FROM trigger_rules ORDER BY id ASC")
    fun getAllRules(): Flow<List<TriggerRuleEntity>>

    @Query("SELECT * FROM trigger_rules WHERE isActive = 1 ORDER BY id ASC")
    suspend fun getActiveRulesSync(): List<TriggerRuleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRule(rule: TriggerRuleEntity): Long

    @Update
    suspend fun updateRule(rule: TriggerRuleEntity)

    @Query("DELETE FROM trigger_rules WHERE id = :id")
    suspend fun deleteRuleById(id: Long)

    @Query("UPDATE trigger_rules SET matchCount = matchCount + 1 WHERE id = :id")
    suspend fun incrementMatchCount(id: Long)
}
