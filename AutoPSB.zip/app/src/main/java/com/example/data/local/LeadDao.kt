package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.LeadEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LeadDao {
    @Query("SELECT * FROM leads ORDER BY lastInteractionTimestamp DESC")
    fun getAllLeads(): Flow<List<LeadEntity>>

    @Query("SELECT * FROM leads WHERE id = :id")
    fun getLeadById(id: Long): Flow<LeadEntity?>

    @Query("SELECT * FROM leads WHERE phoneNumber = :phoneNumber LIMIT 1")
    suspend fun getLeadByPhone(phoneNumber: String): LeadEntity?

    @Query("SELECT * FROM leads WHERE leadType = :type ORDER BY lastInteractionTimestamp DESC")
    fun getLeadsByType(type: String): Flow<List<LeadEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLead(lead: LeadEntity): Long

    @Update
    suspend fun updateLead(lead: LeadEntity)

    @Query("DELETE FROM leads WHERE id = :id")
    suspend fun deleteLeadById(id: Long)

    @Query("SELECT COUNT(*) FROM leads")
    fun getTotalLeadsCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM leads WHERE leadType = 'NOVO'")
    fun getNewLeadsCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM leads WHERE leadType = 'RECORRENTE'")
    fun getRecurringLeadsCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM leads WHERE leadType = 'RETORNOU'")
    fun getReturnedLeadsCount(): Flow<Int>
}
