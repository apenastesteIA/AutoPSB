package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.BusinessSettingsEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.LeadEntity
import com.example.data.model.LeadStatus
import com.example.data.model.LeadType
import com.example.data.model.MessageSender
import com.example.data.model.MessageType
import com.example.data.model.TriggerActionType
import com.example.data.model.TriggerRuleEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        LeadEntity::class,
        ChatMessageEntity::class,
        TriggerRuleEntity::class,
        BusinessSettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AutoPsbDatabase : RoomDatabase() {
    abstract fun leadDao(): LeadDao
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun triggerRuleDao(): TriggerRuleDao
    abstract fun businessSettingsDao(): BusinessSettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AutoPsbDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AutoPsbDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AutoPsbDatabase::class.java,
                    "autopsb_database"
                )
                    .addCallback(AutoPsbDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AutoPsbDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        private suspend fun populateInitialData(database: AutoPsbDatabase) {
            val settingsDao = database.businessSettingsDao()
            val triggerDao = database.triggerRuleDao()
            val leadDao = database.leadDao()
            val chatDao = database.chatMessageDao()

            // 1. Configurações Iniciais
            settingsDao.insertOrUpdate(
                BusinessSettingsEntity(
                    id = 1,
                    businessName = "Empório & Sabores Gourmet",
                    welcomeEnabled = true,
                    welcomeMessage = "{saudacao}! Seja bem-vindo(a) ao {empresa}! 😊 Como podemos te atender hoje? Você pode digitar o que procura ou clicar em uma opção:",
                    welcomeButtons = "Cardápio e Preços, Endereço e Horários, Chave PIX, Atendente Humano",
                    businessHoursEnabled = true,
                    startHour = "08:00",
                    endHour = "20:00",
                    workDays = "Segunda a Sábado",
                    offHoursMessage = "Olá! No momento estamos fora do nosso expediente comercial. Nosso horário é de Segunda a Sábado das 08h às 20h. Sua mensagem já está salva e entraremos em contato logo cedo!",
                    humanizedDelayEnabled = true,
                    minDelaySeconds = 2,
                    maxDelaySeconds = 4,
                    showTypingStatus = true
                )
            )

            // 2. Gatilhos de Mensagens Pré-configurados (Prontos para Pequenos Comércios)
            val triggers = listOf(
                TriggerRuleEntity(
                    name = "Preço & Cardápio",
                    keywords = "preco, valor, quanto custa, cardapio, catalogo, tabela, preco?",
                    actionType = TriggerActionType.BOTOES_RAPIDOS.name,
                    responseTemplate = "Nosso cardápio atualizado e promoções da semana estão disponíveis! Temos opções a partir de R$ 24,90. O que gostaria de conferir?",
                    quickButtons = "Ver Pratos Executivos, Sobremesas, Fazer Pedido",
                    delaySeconds = 2,
                    includeGreeting = false,
                    matchCount = 14
                ),
                TriggerRuleEntity(
                    name = "Endereço & Localização",
                    keywords = "endereco, onde fica, localizacao, maps, rua, bairro, ponto de referencia",
                    actionType = TriggerActionType.TEXTO_SIMPLES.name,
                    responseTemplate = "📍 Estamos localizados na Av. das Flores, nº 340 - Centro (próximo à Praça Central). Temos estacionamento conveniado em frente!",
                    quickButtons = "Como Chegar, Ver Fotos",
                    delaySeconds = 2,
                    includeGreeting = false,
                    matchCount = 9
                ),
                TriggerRuleEntity(
                    name = "Pagamento & PIX",
                    keywords = "pix, chave pix, pagar, pagamento, cartao, debito, credito",
                    actionType = TriggerActionType.TEXTO_SIMPLES.name,
                    responseTemplate = "Aceitamos PIX, cartões de crédito e débito! 💳 Nossa chave PIX CNPJ é: 12.345.678/0001-90 (Empório e Sabores Ltda). Favor enviar o comprovante por aqui.",
                    quickButtons = "Copiar Chave PIX, Enviar Comprovante",
                    delaySeconds = 2,
                    includeGreeting = false,
                    matchCount = 6
                ),
                TriggerRuleEntity(
                    name = "Atendimento Humano",
                    keywords = "humano, atendente, falar com pessoa, atendente humano, suporte",
                    actionType = TriggerActionType.TRANSF_HUMANO.name,
                    responseTemplate = "Entendido! Estou direcionando você agora para um de nossos atendentes humanos. Um instante que já vamos te responder!",
                    quickButtons = "Cancelar Espera",
                    delaySeconds = 1,
                    includeGreeting = false,
                    matchCount = 5
                )
            )

            triggers.forEach { triggerDao.insertRule(it) }

            // 3. Leads de Demonstração (Novo, Recorrente, e que Retornou após período sem interação)
            val now = System.currentTimeMillis()
            val dayMillis = 24 * 60 * 60 * 1000L

            // Lead 1: NOVO (primeiro contato há 2 horas - Janela de 24h bem ativa)
            val lead1Id = leadDao.insertLead(
                LeadEntity(
                    phoneNumber = "+55 11 98765-4321",
                    name = "Mariana Alves",
                    leadType = LeadType.NOVO.name,
                    firstInteractionTimestamp = now - (2 * 3600 * 1000L),
                    lastInteractionTimestamp = now - (2 * 3600 * 1000L),
                    lastCustomerMessageTimestamp = now - (2 * 3600 * 1000L),
                    messageCount = 2,
                    status = LeadStatus.RESPONDIDO.name,
                    tags = "Primeiro Contato, Interessada em Preços",
                    notes = "Perguntou sobre cardápio executivo."
                )
            )
            chatDao.insertMessage(
                ChatMessageEntity(
                    leadId = lead1Id,
                    sender = MessageSender.CLIENTE.name,
                    content = "Olá, boa tarde! Gostaria de saber o cardápio e os preços de hoje.",
                    timestamp = now - (2 * 3600 * 1000L)
                )
            )
            chatDao.insertMessage(
                ChatMessageEntity(
                    leadId = lead1Id,
                    sender = MessageSender.BOT.name,
                    content = "Boa tarde Mariana! Nosso cardápio atualizado e promoções da semana estão disponíveis! Temos opções a partir de R$ 24,90. O que gostaria de conferir?",
                    timestamp = now - (2 * 3600 * 1000L) + 3000L,
                    type = MessageType.BOTOES.name,
                    quickOptions = "Ver Pratos Executivos, Sobremesas, Fazer Pedido",
                    triggerMatched = "Preço & Cardápio"
                )
            )

            // Lead 2: RECORRENTE (cliente frequente que interage toda semana)
            val lead2Id = leadDao.insertLead(
                LeadEntity(
                    phoneNumber = "+55 11 97123-8899",
                    name = "Rodrigo Mendes",
                    leadType = LeadType.RECORRENTE.name,
                    firstInteractionTimestamp = now - (30 * dayMillis),
                    lastInteractionTimestamp = now - (5 * 3600 * 1000L),
                    lastCustomerMessageTimestamp = now - (5 * 3600 * 1000L),
                    messageCount = 18,
                    status = LeadStatus.CONVERTIDO.name,
                    tags = "Cliente Fiel, Pedido Semanal, VIP",
                    notes = "Sempre pede aos sábados."
                )
            )
            chatDao.insertMessage(
                ChatMessageEntity(
                    leadId = lead2Id,
                    sender = MessageSender.CLIENTE.name,
                    content = "Oi! Qual a chave PIX de vocês mesmo? Vou adiantar o pagamento do pedido.",
                    timestamp = now - (5 * 3600 * 1000L)
                )
            )
            chatDao.insertMessage(
                ChatMessageEntity(
                    leadId = lead2Id,
                    sender = MessageSender.BOT.name,
                    content = "Olá Rodrigo! Aceitamos PIX, cartões de crédito e débito! 💳 Nossa chave PIX CNPJ é: 12.345.678/0001-90. Favor enviar o comprovante por aqui.",
                    timestamp = now - (5 * 3600 * 1000L) + 2500L,
                    type = MessageType.TEXTO.name,
                    triggerMatched = "Pagamento & PIX"
                )
            )

            // Lead 3: RETORNOU (ficou inativo por 15 dias e mandou mensagem hoje! Excelente métrica de retenção)
            val lead3Id = leadDao.insertLead(
                LeadEntity(
                    phoneNumber = "+55 11 96543-2100",
                    name = "Juliana Costa",
                    leadType = LeadType.RETORNOU.name,
                    firstInteractionTimestamp = now - (45 * dayMillis),
                    lastInteractionTimestamp = now - (45 * 60 * 1000L),
                    lastCustomerMessageTimestamp = now - (45 * 60 * 1000L),
                    messageCount = 7,
                    status = LeadStatus.AGUARDANDO_HUMANO.name,
                    tags = "Retorno (>15 dias), Orçamento Especial",
                    notes = "Cliente antiga que retornou para orçamento de evento corporativo."
                )
            )
            chatDao.insertMessage(
                ChatMessageEntity(
                    leadId = lead3Id,
                    sender = MessageSender.CLIENTE.name,
                    content = "Olá sumidos! Queria falar com um atendente humano para um orçamento de evento.",
                    timestamp = now - (45 * 60 * 1000L)
                )
            )
            chatDao.insertMessage(
                ChatMessageEntity(
                    leadId = lead3Id,
                    sender = MessageSender.BOT.name,
                    content = "Entendido Juliana! Que bom ter você de volta! 😊 Estou direcionando você agora para um de nossos atendentes humanos. Um instante que já vamos te responder!",
                    timestamp = now - (45 * 60 * 1000L) + 2000L,
                    type = MessageType.BOTOES.name,
                    quickOptions = "Cancelar Espera",
                    triggerMatched = "Atendimento Humano"
                )
            )
        }
    }
}
