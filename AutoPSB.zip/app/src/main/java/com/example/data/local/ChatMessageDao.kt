package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.ChatMessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages WHERE leadId = :leadId ORDER BY timestamp ASC")
    fun getMessagesForLead(leadId: Long): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentMessages(limit: Int = 20): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity): Long

    @Query("SELECT COUNT(*) FROM chat_messages WHERE sender = 'BOT'")
    fun getBotResponsesCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM chat_messages WHERE sender = 'CLIENTE'")
    fun getCustomerMessagesCount(): Flow<Int>
}
