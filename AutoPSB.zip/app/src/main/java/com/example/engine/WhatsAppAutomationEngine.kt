package com.example.engine

import com.example.data.model.BusinessSettingsEntity
import com.example.data.model.LeadEntity
import com.example.data.model.LeadStatus
import com.example.data.model.LeadType
import com.example.data.model.MessageType
import com.example.data.model.TriggerActionType
import com.example.data.model.TriggerRuleEntity
import java.text.Normalizer
import java.util.Calendar

data class ProcessedResponse(
    val replyText: String,
    val quickButtons: String,
    val messageType: String,
    val triggerMatched: String?,
    val isHandledByBot: Boolean,
    val requiresHumanAttention: Boolean,
    val delayMs: Long
)

object WhatsAppAutomationEngine {

    private const val SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000L

    /**
     * Remove acentos e caracteres especiais para comparação flexível de palavras-chave.
     */
    fun normalizeText(input: String): String {
        val normalized = Normalizer.normalize(input, Normalizer.Form.NFD)
        return normalized.replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
            .lowercase()
            .trim()
    }

    /**
     * Retorna a saudação humanizada adequada ao horário do dia ("Bom dia", "Boa tarde", "Boa noite").
     */
    fun getGreetingForCurrentTime(): String {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 5..11 -> "Bom dia"
            in 12..17 -> "Boa tarde"
            else -> "Boa noite"
        }
    }

    /**
     * Verifica se o momento atual está dentro do horário de funcionamento cadastrado.
     */
    fun isWithinBusinessHours(settings: BusinessSettingsEntity): Boolean {
        if (!settings.businessHoursEnabled) return true

        try {
            val calendar = Calendar.getInstance()
            val currentMinutes = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)

            val startParts = settings.startHour.split(":")
            val startMinutes = startParts[0].trim().toInt() * 60 + startParts[1].trim().toInt()

            val endParts = settings.endHour.split(":")
            val endMinutes = endParts[0].trim().toInt() * 60 + endParts[1].trim().toInt()

            return currentMinutes in startMinutes..endMinutes
        } catch (e: Exception) {
            return true
        }
    }

    /**
     * Determina o tipo de lead com base no histórico de interações:
     * - NOVO: Nunca interagiu antes
     * - RETORNOU: Estava inativo há mais de 7 dias e mandou nova mensagem
     * - RECORRENTE: Interagiu nos últimos 7 dias
     */
    fun classifyLead(existingLead: LeadEntity?, now: Long = System.currentTimeMillis()): LeadType {
        if (existingLead == null) {
            return LeadType.NOVO
        }
        val elapsedSinceLastContact = now - existingLead.lastInteractionTimestamp
        return if (elapsedSinceLastContact > SEVEN_DAYS_MS) {
            LeadType.RETORNOU
        } else {
            LeadType.RECORRENTE
        }
    }

    /**
     * Processa a mensagem recebida pelo WhatsApp (via Webhook Meta Cloud API ou Simulador),
     * localiza o melhor gatilho ou aplica as regras de fora de horário e boas-vindas.
     */
    fun processIncomingMessage(
        messageContent: String,
        leadName: String,
        leadType: LeadType,
        activeRules: List<TriggerRuleEntity>,
        settings: BusinessSettingsEntity
    ): ProcessedResponse {
        val normalizedMsg = normalizeText(messageContent)
        val greeting = getGreetingForCurrentTime()
        val companyName = settings.businessName

        // 1. Verificar se está fora de expediente
        if (!isWithinBusinessHours(settings)) {
            val offHoursText = settings.offHoursMessage
                .replace("{saudacao}", greeting)
                .replace("{nome}", leadName)
                .replace("{empresa}", companyName)

            return ProcessedResponse(
                replyText = offHoursText,
                quickButtons = "Deixar Recado, Ver Cardápio",
                messageType = MessageType.TEXTO.name,
                triggerMatched = "Fora de Horário Comercial",
                isHandledByBot = true,
                requiresHumanAttention = false,
                delayMs = calculateHumanizedDelay(settings)
            )
        }

        // 2. Procurar regra por palavra-chave
        for (rule in activeRules) {
            val keywords = rule.keywords.split(",").map { normalizeText(it) }
            val matched = keywords.any { kw ->
                kw.isNotBlank() && (normalizedMsg.contains(kw) || kw.contains(normalizedMsg))
            }

            if (matched) {
                var responseText = rule.responseTemplate
                    .replace("{empresa}", companyName)
                    .replace("{nome}", leadName)

                if (rule.includeGreeting) {
                    responseText = "$greeting $leadName! $responseText"
                }

                val isHumanTransfer = rule.actionType == TriggerActionType.TRANSF_HUMANO.name
                val messageType = when (rule.actionType) {
                    TriggerActionType.BOTOES_RAPIDOS.name -> MessageType.BOTOES.name
                    TriggerActionType.LISTA_OPCOES.name -> MessageType.LISTA.name
                    else -> MessageType.TEXTO.name
                }

                return ProcessedResponse(
                    replyText = responseText,
                    quickButtons = rule.quickButtons,
                    messageType = messageType,
                    triggerMatched = rule.name,
                    isHandledByBot = true,
                    requiresHumanAttention = isHumanTransfer,
                    delayMs = (rule.delaySeconds * 1000L).coerceAtLeast(1000L)
                )
            }
        }

        // 3. Caso não bata em nenhuma palavra-chave, enviar boas-vindas humanizada se habilitada
        if (settings.welcomeEnabled) {
            val welcomeText = settings.welcomeMessage
                .replace("{saudacao}", greeting)
                .replace("{nome}", leadName)
                .replace("{empresa}", companyName)

            val customizedText = if (leadType == LeadType.RETORNOU) {
                "$greeting $leadName! Que alegria ter você de volta por aqui! 😊\n\n$welcomeText"
            } else {
                welcomeText
            }

            return ProcessedResponse(
                replyText = customizedText,
                quickButtons = settings.welcomeButtons,
                messageType = MessageType.BOTOES.name,
                triggerMatched = "Boas-Vindas Padrão",
                isHandledByBot = true,
                requiresHumanAttention = false,
                delayMs = calculateHumanizedDelay(settings)
            )
        }

        // 4. Fallback simples
        return ProcessedResponse(
            replyText = "Olá $leadName! Recebemos sua mensagem e já vamos te responder com todo carinho. Se precisar de algo específico, digite sua dúvida!",
            quickButtons = "Falar com Atendente, Ver Informações",
            messageType = MessageType.TEXTO.name,
            triggerMatched = "Resposta Padrão",
            isHandledByBot = true,
            requiresHumanAttention = true,
            delayMs = calculateHumanizedDelay(settings)
        )
    }

    private fun calculateHumanizedDelay(settings: BusinessSettingsEntity): Long {
        if (!settings.humanizedDelayEnabled) return 500L
        val min = settings.minDelaySeconds.coerceAtLeast(1)
        val max = settings.maxDelaySeconds.coerceAtLeast(min)
        val randomSec = (min..max).random()
        return randomSec * 1000L
    }
}
