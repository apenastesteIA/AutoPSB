package com.example

import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleRobolectricTest {

  @Test
  fun testStringAppName() {
    val expectedName = "AutoPSB"
    assertEquals("AutoPSB", expectedName)
  }
}
