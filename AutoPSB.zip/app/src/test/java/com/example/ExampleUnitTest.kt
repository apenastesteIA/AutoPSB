package com.example

import com.example.data.model.LeadEntity
import com.example.data.model.LeadType
import com.example.engine.WhatsAppAutomationEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testTextNormalization() {
        val raw = "Qual é o Preço do Cardápio de Almoço?"
        val normalized = WhatsAppAutomationEngine.normalizeText(raw)
        assertEquals("qual e o preco do cardapio de almoco?", normalized)
    }

    @Test
    fun testLeadClassification_newLead() {
        val result = WhatsAppAutomationEngine.classifyLead(null)
        assertEquals(LeadType.NOVO, result)
    }

    @Test
    fun testLeadClassification_recurringLead() {
        val now = System.currentTimeMillis()
        val recentLead = LeadEntity(
            phoneNumber = "+5511999991111",
            name = "Cliente Recorrente",
            lastInteractionTimestamp = now - (2 * 24 * 60 * 60 * 1000L) // 2 dias atrás
        )
        val result = WhatsAppAutomationEngine.classifyLead(recentLead, now)
        assertEquals(LeadType.RECORRENTE, result)
    }

    @Test
    fun testLeadClassification_returnedLeadAfterSevenDays() {
        val now = System.currentTimeMillis()
        val inactiveLead = LeadEntity(
            phoneNumber = "+5511999992222",
            name = "Cliente Inativo",
            lastInteractionTimestamp = now - (15 * 24 * 60 * 60 * 1000L) // 15 dias atrás (> 7 dias)
        )
        val result = WhatsAppAutomationEngine.classifyLead(inactiveLead, now)
        assertEquals(LeadType.RETORNOU, result)
    }

    @Test
    fun testMeta24HourWindowCalculation() {
        val now = System.currentTimeMillis()
        val activeLead = LeadEntity(
            phoneNumber = "+5511999993333",
            name = "Janela Ativa",
            lastCustomerMessageTimestamp = now - (2 * 60 * 60 * 1000L) // 2 horas atrás
        )
        assertTrue(activeLead.isWindowActive())
        assertTrue(activeLead.remainingSessionWindowMillis() > 0)

        val expiredLead = LeadEntity(
            phoneNumber = "+5511999994444",
            name = "Janela Expirada",
            lastCustomerMessageTimestamp = now - (25 * 60 * 60 * 1000L) // 25 horas atrás (> 24h)
        )
        assertFalse(expiredLead.isWindowActive())
        assertEquals(0L, expiredLead.remainingSessionWindowMillis())
    }
}
